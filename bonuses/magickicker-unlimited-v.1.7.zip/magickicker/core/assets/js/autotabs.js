/**
 * create magic tabs
 *
 * @version 1.1
 * @since 1.21
 * @requires wordpres 3.0+ < 3.6
 */
(function( $ ){
  /**
   * create tabs 
   */	
  $.fn.mgkAutoTabs = function(options) { 
  		// defaults
		var settings= {
			index   : 1, 	
			select  : -1,
			label   : 'New Tab', 
			url     : 'ajaxdata.html', 
			tabhash : '#ui-tab-'+ (new Date().getTime() + Math.round(Math.random()*100))
	  	};
		// extend
		if ( options ) $.extend( settings, options );		
		// select
		if(settings.select == '-1')	settings.select = settings.index;					
		// remove old at same index		
		this.tabs( 'remove', settings.index);
		// add new 
		this.tabs( 'add', settings.tabhash, settings.label, settings.index);
		// set url
		this.tabs( 'url', settings.index, settings.url);
		// select
		this.tabs( 'select', settings.select );		
		// refresh
		this.tabs( 'refresh' );
		// return self
		return this;
  };  
})( jQuery );

mgk_remove_tab=function(selector, index){
	jQuery( selector ).tabs('remove', index);	
}

/**
 * reload tab url
 *
 * @since 1.2
 */	
mgk_reload_tab= function(selector, index, section, url, action){
	// section									   
	switch(section){
		case 'admin':
		default:
			// action
			var action = action || 'cached';
			// + ' .content-div'
			// reset options
			jQuery( selector ).tabs( 'option', 'ajaxOptions', {data:{do_action : action}});
			// set new url							   	
			jQuery( selector ).tabs( 'url', index, url );	   
			// reload
			jQuery( selector ).tabs( 'load', index);	
		break;		
	}	
}

/**
 * select tab
 *
 * @since 1.30
 * @todo fix for wp3.5<
 */
 mgk_select_tab=function(selector, index){
 	jQuery( selector ).tabs( "select", index); 	
 }