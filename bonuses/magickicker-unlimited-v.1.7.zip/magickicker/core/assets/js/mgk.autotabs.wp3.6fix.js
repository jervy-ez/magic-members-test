/**
 * create magic tabs
 *
 * @version 1.2
 * @since 1.7.0
 * @requires wordpres 3.6+
 */
(function( $ ){
  /**
   * create tabs 
   */
  $.fn.mgkAutoTabs = function(options) { 
  		// defaults
		var settings = {
			index   : 1, 	
			select  : -1,
			label   : 'New Tab', 
			url     : 'ajaxdata.html', 
			tabhash : '#ui-tab-'+ (new Date().getTime() + Math.round(Math.random()*100))
		};
		// extend
		if ( options ) $.extend( settings, options );
		
		// remove old at same index		
		mgk_remove_tab(this.selector, settings.index);			

		// add new		
		mgk_add_tab(this.selector, settings.url, settings.label);

		// activate
		if( settings.select != '-1' ) jQuery( this.selector ).tabs( "option", "active", settings.select );

		// return self
		return this;
  };  
  
})( jQuery );// end closure

/**
 * private function, add tab
 */
mgk_add_tab=function(selector, url, label){
	// add
	jQuery( "<li><a href='"+ url +"'>"+ label +"</a></li>" ).appendTo( selector + " .ui-tabs-nav" );
	// refresh
	jQuery( selector ).tabs( "refresh" );		
}	

/**
 * private function, remove tab
 */
mgk_remove_tab=function(selector, index){
	// Remove the tab
	var tab = jQuery( selector ).find( ".ui-tabs-nav li:eq( " + index + " )" ).remove();
	// Find the id of the associated panel
	var panelId = tab.attr( "aria-controls" );
	// Remove the panel
	jQuery( "#" + panelId ).remove();
	// Refresh the tabs widget
	jQuery( selector ).tabs( "refresh" );
}	 

/**
 * reload tab url
 *
 * @since 1.7.0
 * @todo fix for wp3.6
 */	
mgk_reload_tab = function(selector, index, section, url, action){
	// section									   
	switch(section){
		case 'admin':
		default:
			// action
			var action = action || 'cached';
			// set url
			jQuery( selector ).find('ul.tabs').find('li:eq(' + index + ')').find('a.ui-tabs-anchor').attr('href', url);
			// on load
			jQuery( selector ).on( "tabsbeforeload", function( event, ui ) {
				ui.ajaxSettings.type = 'POST'; 
				ui.ajaxSettings.hasContent = true;
				ui.jqXHR.setRequestHeader( "Content-Type", ui.ajaxSettings.contentType );
				ui.ajaxSettings.data = jQuery.param( { do_action: action}, ui.ajaxSettings.traditional );		 
			} );
			// load
			jQuery( selector ).tabs( 'load', index); 
			// refresh
			jQuery( selector ).tabs( 'refresh' );
		break;		
	}	
}

/**
 * select tab
 *
 * @since 1.7.0
 * @todo fix for wp3.6
 */
 mgk_select_tab=function(selector, index){
 	jQuery( selector ).tabs( "option", "active", index);	
 }