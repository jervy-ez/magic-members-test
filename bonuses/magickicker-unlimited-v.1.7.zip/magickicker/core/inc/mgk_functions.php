<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
/**
 * For more information on hooks, actions, and filters, see http://codex.wordpress.org/Plugin_API.
 *
 * @package WordPress
 * @subpackage magickicker
 * @since 1.0	
 */


/**
 * dump array or object data
 *
 * @param mixed $array
 * @param boolean $return 
 * @return mixed
 */
function mgk_array_dump($array, $return=false){
	// dump
	$dump = sprintf('<pre>%s</pre>', print_r($array, true));
	// return 
	if($return) return $dump;
	// print
	echo $dump;
}
/**
 * print array or object data
 *
 * @param mixed $array
 * @param boolean $return 
 * @return mixed
 */
function mgk_pr($array, $return=false){
// return
	return mgk_array_dump($array, $return);
}
/**
 * write to a log file
 *
 * @param string $data
 * @return void
 */
function mgk_log($data, $filename=NULL, $suffix=true){
	// line count
	static $line=1;	
    // define
    if( !defined('MGK_LOGS_DIR')){
    	define('MGK_LOGS_DIR', WP_CONTENT_DIR . '/uploads/mgk/logs/');
    }
    // create
    if(!file_exists(MGK_LOGS_DIR)){
		@wp_mkdir_p(MGK_LOGS_DIR);
	}	
	// log to same file
	if($suffix){
		// define
		if(!defined('MGK_LOG_REQUEST_ID')) define('MGK_LOG_REQUEST_ID', date('mdYHis'));
		 // file name 
		$filename = (!$filename) ? MGK_LOG_REQUEST_ID : ($filename . '_' . MGK_LOG_REQUEST_ID);	
	}else{
	// different files
		$filename = (!$filename) ? date('mdYHis') : $filename;	
	}
	
	// data, array to string
	if(is_array($data) || is_object($data)) $data = mgk_array_dump($data, true);
	// line feed	
	$crlf = "\n";
	$end_crlf = "\n\r";
	// open
	if($fp = fopen(MGK_LOGS_DIR . $filename . '.log', 'a+')){
		// write
		fwrite($fp, $crlf . ($line++) . '. ['.date('d-m-Y H:i:s').']: ' . $crlf . str_repeat('-',100) . $crlf . $data . $end_crlf);
		// close
		fclose($fp);
		// return success
		return true;
	}
	// error
	return false;
}
/**
 * box header for admin ui 
 *  
 * @section admin
 * @param string $title
 * @param string $helpkey
 * @param boolean $return 
 * @param array $attributes
 * @return mixed
 */
function mgk_box_top($title, $helpkey="", $return=false, $attributes=false){
	// defaults
	$attributes_default=array('width'=>845,'style'=>'margin:10px 0;');
	// attributes
	if(is_array($attributes)){
		$options=array_merge($attributes_default,$attributes);
	}else{
		$options=$attributes_default;
	}
	// local
	extract($options);	
	
	// help key
	if(empty($helpkey)){
		$helpkey=strtolower(preg_replace('/\s+/','',$title));
	}
	// html
	$html= '<div class="mgk-panel-box" style="'.$style.($width ? 'width: ' . ($width) . 'px;':'') .'">			
				<div class="box-title" style="' .($width ? 'width: ' . ($width-5) . 'px;':'') . '">			
					<h3>'.__($title, 'mgk').'</h3>				
						<div class="box-triggers">
							<img src="'.MGK_ASSETS_URL.'images/panel/help-image.png" alt="description" class="box-description" />							
							<img src="'.MGK_ASSETS_URL.'images/panel/television.png" alt="video" class="box-video" />
						</div>						
						<div class="box-description-content">				
							<p>'.mgk_get_tip($helpkey).'</p>				
						</div> <!-- end box-description-content div -->						
						<div class="box-video-content">				
							<p>'.mgk_get_video($helpkey).'</p>				
						</div> <!-- end box-video-content div -->				
					</div> <!-- end div box-title -->				
					<div class="box-content">';	
			  
	// return output
	if ($return) {
		return $html;
	} else {
		echo $html;
	}
}

/**
 * box footer for admin ui
 *
 * @param boolean $return 
 * @return mixed
 */
function mgk_box_bottom($return=false){
	$html = '</div>
		   </div>';
	if ($return) {
		return $html;
	} else {
		echo $html;
	}
}

/**
 * tooltip information
 *
 * @param string $key
 * @return string
 */
function mgk_get_tip($key){
	global 	$mgk_tips_info;
	return (isset($mgk_tips_info[$key]))?$mgk_tips_info[$key]:"[tip '$key' missing]";
}	

/**
 *  videos
 *
 * @param string $key
 * @return string
 */	
function mgk_get_video($key){	
	global 	$mgk_videos_info;
	return (isset($mgk_videos_info[$key]))?$mgk_videos_info[$key]:"[video '$key' missing]";
}

/**
 * for excecuting the process
 *
 * @param string $fun
 * @param mixed $default
 * @return void 
 */
function mgk_call_process($func,$default='f_index'){
	// set name flag
	$func="f_{$func}";
	// when set
	if(isset($func) && is_callable($func)){		
		call_user_func($func);
	// default	
	}else if(isset($default) && is_callable($default)){
		call_user_func($default);
	// else
	}else{
		echo 'error loading method';
	}
}

/**
 * infobar
 * displayes plugin info on admin ui
 * 
 * @param void
 * @return void
 */
function mgk_render_infobar() {
	$style = 'style="color:#161616; text-decoration:none;"';	

	echo '<div id="mgk-info" style="float:right; color:#161616; padding-top:10px; padding-right:15px;">
			<strong>
				<a href="http://www.magicmembers.com/" ' . $style . '>'.__('Magic Kicker','mgk').'</a> |
				<a href="http://www.magicmembers.com/support-center/" ' . $style . '>'.__('Support','mgk').'</a> |
				<a href="http://www.magicmembers.com/' . MGK_PLUGIN_PRODUCT_URL .'" ' . $style . ' target="_blank">V. ' . MGK_PLUGIN_VERSION . ' - '. MGK_PLUGIN_PRODUCT_NAME .'</a>				
			</strong>
		</div>';
}

/**
 * fetches settings from database
 * 
 * @param string $key
 * @param string $group
 * @param mixed $default
 * @return mixed
 */
function mgk_get_setting($key,$group='general',$default=''){
	$mgk_settings =get_option('mgk_settings');
	$settings     =$mgk_settings[$group];	
	
	return (isset($settings[$key]))?$settings[$key]:$default;
}

/**
 * for sending mail
 * 
 * @param string $to
 * @param string $subject
 * @param string $message
 * @param string  $from
 * @param string $subject_charset
 * @param string $message_charset
 * @return string
 */
function mgk_mail($to, $subject, $message, $from=null, $subject_charset = 'UTF-8', $message_charset = 'UTF-8'){		
	// form	
	if( $from ){
		list($from_name,$from_email) = explode(',',$from);	
	}else{
		$from_name  = get_option('blogname');
		$from_email = get_option('admin_email');
	}		
	// bcc
	$bcc_email = '';
	
	// header
	$headers = "MIME-Version: 1.0
	From: {$from_name} <{$from_email}>
	Reply-To: {$from_email}
	{$bcc_email}
	Return-Path: {$from_email}
	X-Sender: {$from_email}
	X-Mailer: PHP/" . phpversion() . "
	Content-Type: text/html; charset=\"$message_charset\"
	Content-Transfer-Encoding: 8bit";
    // sent
	@wp_mail($to, $subject, $message, $headers);
}

/**
 * sending a request by connecting to a server
 * 
 * @param string $url
 * @param boolean $error_string
 * @return string
 */
function mgk_remote_request($url, $error_string=true) {
    $string = '';
        
	if (ini_get('allow_url_fopen')) {
		if (!$string = @file_get_contents($url)) {
            if ($error_string) {
				$string = 'Could not connect to the server to make the request.';
            }
		}
	} else if (extension_loaded('curl')) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$string = curl_exec($ch);
		curl_close($ch);
	} else if ($error_string) {
	    $string = 'This feature will not function until either CURL or fopen to urls is turned on.';
	}

	return $string;
}

/**
 * download update file
 *
 * @param string $url
 * @return string
 */
function mgk_download_url( $url ) {	
	//WARNING: The file is not automatically deleted, The script must unlink() the file.
	if ( ! $url )
		return new WP_Error('http_no_url', __('Invalid URL Provided'));

	$tmpfname = mgk_tempnam($url);
	if ( ! $tmpfname )
		return new WP_Error('http_no_file', __('Could not create Temporary file'));

	$handle = @fopen($tmpfname, 'wb');
	if ( ! $handle )
		return new WP_Error('http_no_file', __('Could not create Temporary file'));

	$response = wp_remote_get($url, array('timeout' => 120));
    
	if ( is_wp_error($response) ) {
		fclose($handle);
		unlink($tmpfname);
		return $response;
	}

	if ( $response['response']['code'] != '200' ){
		fclose($handle);
		unlink($tmpfname);
		return new WP_Error('http_404', trim($response['response']['message']));
	}

	fwrite($handle, $response['body']);
	fclose($handle);

	return $tmpfname;
}

/**
 * tempname
 * display the filename from dirctory
 *
 * @param string $url
 * @param string $dir
 * @return string
 */
function mgk_tempnam($url = '', $dir = ''){
	if ( empty($dir) )
		$dir = get_temp_dir();
	
	// parse filename
	parse_str($url);
	// set filename
	$filename = (!empty($filename))?$filename:basename($url);
	if (empty($filename) )
		$filename = time();

	$filename = $dir . wp_unique_filename($dir, $filename);
	touch($filename);
	return $filename;
}

/**
 * pad string
 *
 * @param string $str
 * @param int $len
 * @param string $linebrk
 * @return string
 * @deprecated
 */
function mgk_pad_string($str,$len=50,$linebrk=""){
	// trim space
	$str=trim(strip_tags($str));
	// nothing
	if($str=="")
		return "&nbsp;";
	
	// when length matched
	if(strlen($str)>$len){
		if($linebrk==""){
			# no line break </br>
			$str=substr($str,0,$len-5);
			$str=str_pad($str,$len,".",STR_PAD_RIGHT);
		}else{
			# break after length
			$str=chunk_split($str,$len,$linebrk);	   
		}
	}
	// return 
	return $str;
} 

/**
 * get jquery ui for wp version
 * 
 * @param void
 * @return string
 * @since 1.29
 */
function mgk_get_jqueryui_on_wp_version(){
	// array
	$versions = array('3.6' => '1.10.3', '3.5' => '1.9.2', '3.0' => '1.8.16', '2.9' => '1.7.3');
	// loop
	foreach( $versions as $wp_ver => $jqui_ver){
		// greater or equal
		if ( mgk_compare_wp_version( $wp_ver, '>=' ) ){
			// set
			$jqueryui_version = $jqui_ver;									
			break;
		}	
	}

	// default
	if( ! isset($jqueryui_version) ) $jqueryui_version = '1.7.2';

	// return
	return $jqueryui_version;
}

/**
 * get jquery ui version
 *
 * @param void
 * @return string
 * @since 1.7.0
 */
function mgk_get_jqueryui_version(){
	// check db
	if( ! $jqueryui_version = get_option('mgk_jqueryui_version') ){// not defined, use as coded	
		// calc on wp version
		$jqueryui_version = mgk_get_jqueryui_on_wp_version();
		// save 								
		update_option('mgk_jqueryui_version', $jqueryui_version); // and update	
	}else{
		// calc on wp version
		$jqueryui_version = mgk_get_jqueryui_on_wp_version();
		// check latest not used
		if( get_option('mgk_jqueryui_version') != $jqueryui_version ){
			// save 								
			update_option('mgk_jqueryui_version', $jqueryui_version); // and update	
		}
	}	
	
	// return
	return $jqueryui_version;
}

/**
 * version of jquery ui
 *
 * @param void
 * @return string
 * @deprecated
 */
function mgk_get_jqueryui_version_old(){
	// compare version if greater than 2.9
	/*if (version_compare(get_bloginfo('version'), '2.9', '>=')){
		// ui 1.7.3 for jQuery 1.4+ options : 1.7.3 , 1.8.2
		$jqueryui_version = get_option('mgk_jqueryui_version');
		// not defined, use as coded
		if(!$jqueryui_version){
			// set default
			$jqueryui_version = '1.8.16';	
			// update option	
			update_option('mgk_jqueryui_version', $jqueryui_version); // and update		 
		}
	}else{
		// ui 1.7.2 for jQuery 1.3.2+
		$jqueryui_version = '1.7.2';			 
	}*/

	// compare version if greater than 2.9
	if (version_compare(get_bloginfo('version'), '2.9', '>=') && version_compare(get_bloginfo('version'), '3.0', '<')){
		// ui 1.7.3 for jQuery 1.4+ options : 1.7.3 , 1.8.2
		$jqueryui_version = get_option('mgk_jqueryui_version');
		if(!$jqueryui_version){// not defined, use as coded
			$jqueryui_version = '1.7.3';		
			update_option('mgk_jqueryui_version', $jqueryui_version); // and update		 
		}
	// compare version if greater than 3.5 issue #1182
	}else if (version_compare(get_bloginfo('version'), '3.5', '>=')){
		$jqueryui_version = get_option('mgk_jqueryui_version');
		if(!$jqueryui_version){// not defined, use as coded
			$jqueryui_version = '1.9.2';		
			update_option('mgk_jqueryui_version', $jqueryui_version); // and update		 
		}
	}
	// compare version if greater than 3.0 issue #1010
	else if (version_compare(get_bloginfo('version'), '3.0', '>=')){
		$jqueryui_version = get_option('mgk_jqueryui_version');
		if(!$jqueryui_version){// not defined, use as coded
			$jqueryui_version = '1.8.16';		
			update_option('mgk_jqueryui_version', $jqueryui_version); // and update		 
		}
	}	
	else {
		// ui 1.7.2 for jQuery 1.3.2+
		$jqueryui_version = '1.7.2';			 
	}
	// return
	return $jqueryui_version;
}

/**
 * deep stripslashes
 *
 * @param string $data
 * @return string
 */
function mgk_stripslashes_deep($data){	
	// clean till found '\'
	do{
		$data = stripslashes($data);
	}while(strpos($data, '\\') !==false);	
	// return
	return $data;
}

/**
 * recursive slash remove
 *
 * @param array $v
 * @return array
 */
function mgk_array_stripslashes($v) {		
	// return stripped
	return is_array($v) ? array_map('mgk_array_stripslashes', $v) : stripslashes($v);	
}

/**
 * recursive slash add
 *
 * @param array $v
 * @return array
 */
function mgk_array_addslashes($v) {
	// is it enabled, return as 
	if(MGK_MAGIC_QUOTES_GPC){
		return $v;
	}
	// return stripped
	return is_array($v) ? array_map('mgk_array_addslashes', $v) : addslashes($v);
}

/**
 * check lockout
 * logic fails for once logged in user ip tracking
 *
 * @param string $current_user
 * @return boolean
 */
function mgk_check_lockout($current_user) {
	global $wpdb;

	$return = false;
	$lockout = get_user_meta($current_user->ID, 'mgk_locked_out', true);
	
	// not locked out	
	if (!$lockout) {

		$time_offset = time() - (mgk_get_setting('timeout_minutes') * 60); 
		$max_logins  = mgk_get_setting('timeout_logins'); 

		$sql = 'SELECT COUNT(DISTINCT(`ip_address`)) FROM `' . MGK_TBL_USER_IPS . '` 
				WHERE `user_id` = ' . $current_user->ID . '
				AND UNIX_TIMESTAMP(access_dt) > ' . $time_offset . ' 
				AND `logout_at` IS NULL';		
		// log
		// mgk_log('mgk_check_lockout sql - '.$sql, __FUNCTION__);					
			
		$logins = $wpdb->get_var($sql);
		
		//some times mysql server timezone could be configured differently, checking alternative way
		if(!$logins) {			
			$t_sql = 'SELECT DISTINCT(`ip_address`), access_dt FROM `' . MGK_TBL_USER_IPS . '` 
					WHERE `user_id` = ' . $current_user->ID . '	AND `logout_at` IS NULL';
			$l_results = $wpdb->get_results($t_sql);
			//loop
			foreach ($l_results as $l_result) {	
				//check
				if(strtotime($l_result->access_dt) > $time_offset) {
					$logins++;
				}
			}
		}		
		
		// mgk_log('mgk_check_lockout logins - '.$logins. ' X '.$max_logins, __FUNCTION__);
		// exceed limit
		if ($logins > $max_logins) {
			$return = true;
		}
	} else if ($lockout == 1) {
		$return = true;
	} else if ($lockout > 1) {
		$lockout_expiry = mgk_check_lockout_expiry($current_user);

		if ($lockout_expiry > time()) {
			$return = true;
		}
	}

	
	return $return;
}

/**
 * check lockout expiry
 * 
 * @param string $user
 * @return string
 */
function mgk_check_lockout_expiry($user) {
	$lockout_expiry = 0;

	if ($locked_out_since = get_user_meta($user->ID, 'mgk_locked_out', true)) {
		$logout_secs    = mgk_get_setting('lockout_minutes') * 60;
		$lockout_expiry = ($locked_out_since + $logout_secs);
	}

	return $lockout_expiry;
}

/**
 * ip block
 *
 * @param int $ip_address
 * @return int
 */
function mgk_ip_is_blocked($ip_address) {
	global $wpdb;

	$sql = 'SELECT COUNT(id) FROM `' . MGK_TBL_BLOCKED_IPS . '` WHERE `ip_address` = "'.$ip_address.'"';
	
	// mgk_log('mgk_ip_is_blocked - '.$sql);

	return $wpdb->get_var($sql);

}

/**
 * filter post
 *
 * @param array $content
 * @return array
 */
function mgk_filter_post($content) {

	$pattern = "'\[\[user_ip]\]'is";
	$content = preg_replace_callback($pattern, "mgk_current_user_ip", $content);

	$pattern = "'\[\[user_last_ip]\]'is";
	$content = preg_replace_callback($pattern, "mgk_user_last_ip", $content);

	$pattern = "'\[\[user_last_login]\]'is";
	$content = preg_replace_callback($pattern, "mgk_user_last_login", $content);

	return $content;
}

/**
 * log ip filter on authenticate
 *
 * @param string $user
 * @return string
 */
function mgk_authenticate_user($user) {
	global $wpdb;
	
	// called after mgm authenticate, check error, admin user and not deactivated by some plugin
	if( is_wp_error($user) || is_super_admin($user->ID) || apply_filters( 'mgk_before_authenticate', $user ) === FALSE )
		return $user;

	// init 
	$is_error = false;
	$ip_address = mgk_current_user_ip();
	// other user
	if (get_user_meta($user->ID, 'mgk_locked_out', true) > 1) {
		// expired
		$lockout_expiry = mgk_check_lockout_expiry($user);
		// cgeck
		if ($lockout_expiry < time()) {
			update_user_meta($user->ID, 'mgk_locked_out', 0); //clear the lockout
		} else {
			$is_error = true;
		}
	} else if (get_user_meta($user->ID, 'mgk_locked_out', true) == 1) {
		$is_error = true;
	} else if (mgk_ip_is_blocked($ip_address)) {
		$is_error = true;
	} else {
		// data
		$data = array('ip_address'=>$ip_address, 'access_dt' => date('Y-m-d H:i:s'));		
		// user
		if(isset($user->ID) && $user->ID > 0){
			$data['user_id'] = $user->ID; 
		}else{
			$data['user_id'] = 0; 
		}
		// insert		
		$wpdb->insert(MGK_TBL_USER_IPS, $data);		
	}
	
	// has error
	if ($is_error) {
		// message
		$error = new WP_Error();
		// set
		$error->add('locked_out', mgk_get_setting('login_error'));	
		// return	
		return $error;
	}
	
	// return user
	return $user;
}

/**
 * ip check on wp_login/init
 *
 * @param void
 * @return void
 */
function mgk_lockout_user() {
	global $wpdb;
	// get user by login
	// $current_user = get_user_by('login', $user_login);	
	// bet current user
	$current_user = wp_get_current_user();
	// not logged in
	if ( empty( $current_user ) )
		return false;
	
	// log
	// mgk_log('mgk_lockout_user '.$current_user->ID);
	
	// other users check 
	if ($current_user->ID && !is_super_admin($current_user->ID)) {
		// log
		// mgk_log('mgk_lockout_user in ');
		// if checked
		if (mgk_check_lockout($current_user)) {
			
			// log
			// mgk_log('mgk_lockout_user mgk_check_lockout true');
			
			$lockout_option = mgk_get_setting('lockout_option');// lockout|logout
			$send_email     = (mgk_get_setting('email_offender') == 'email') ? true : false;

			// log
			// mgk_log('mgk_lockout_user mgk_check_lockout '.$lockout);			
			// mgk_log('mgk_lockout_user send_email '.$send_email);
			
			if ($lockout_option == 'lockout') {
				// value
				$value = $send_email ? 1 : time();				
				// update
				update_user_meta($current_user->ID, 'mgk_locked_out', $value);
			}
			
			// send mail
			if ($send_email){
				// mgk_log('mgk_lockout_user mail sent ');
				mgk_email_user();
			}
			
			// clear cookie
			if(function_exists('wp_clear_auth_cookie')){
				wp_clear_auth_cookie();
			}else{
				wp_clearcookie();
			}
			// mark all ips as logout

			$wpdb->query( 'UPDATE `' . MGK_TBL_USER_IPS . '` SET `logout_at`=NOW() '.
						  'WHERE `user_id` = ' . $current_user->ID . ' AND `logout_at` IS NULL');

			// redirect
			$redirect = mgk_get_setting('redirect_url');	

			// redirect		
			wp_redirect($redirect);
		}
	}
	
	// return true;
}

/**
 * get current url
 *
 * @param void
 * @return string
 */
function mgk_get_current_url(){
	// path
	$path = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $_SERVER['PATHINFO'];
	// host
	if(isset($_SERVER['HTTP_HOST'])){
		$current_url = 'http' . ($_SERVER['SERVER_PORT'] == 443 ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $path;
	}else{
		$current_url = site_url($path);
	}
	// return
	return $current_url;
}

/**
 * log accessed urls
 *
 * @param void
 * @return void
 */
function mgk_url_access_log(){
	global $wpdb;	
	// do not log admin pages
	if(!is_admin()){
		// get user 
		$current_user = wp_get_current_user();
		// current url
		$current_url = mgk_get_current_url();
		// get last logged ip id
		$ip_id = $wpdb->get_var("SELECT `id` FROM `".MGK_TBL_USER_IPS."` WHERE `user_id` = '{$current_user->ID}' ORDER BY `access_dt` DESC LIMIT 1 ");
		// insert
		if($ip_id){
			$wpdb->insert(MGK_TBL_ACCESSED_URLS, array('ip_id'=>$ip_id, 'url'=>$current_url, 'access_dt'=>date('Y-m-d H:i:s')));
		}
	}
}

/**
 * filnename parse
 *
 * @param void
 * @return void
 */
function mgk_is_login_referrer() {
	$url = pathinfo($_SERVER['HTTP_REFERER'], PATHINFO_FILENAME);	
	if($url == 'wp-login'){
		return true;
	}
	// 	false
	return false;
}

/**
 * current IP
 *
 * @param void
 * @return void
 */
function mgk_current_user_ip() {
	if ( isset($_SERVER["REMOTE_ADDR"]) ){
		return $_SERVER["REMOTE_ADDR"] ;
	} else if ( isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ){
		return $_SERVER["HTTP_X_FORWARDED_FOR"];
	} else if ( isset($_SERVER["HTTP_CLIENT_IP"]) ){
		return $_SERVER["HTTP_CLIENT_IP"] ;
	} 
}

/**
 * email to user
 *
 * @param void
 * @return void
 */
function mgk_email_user() {
	// current user
	$current_user = wp_get_current_user();
	// key
	$key = md5('user_' . $current_user->ID) . mt_rand(1,999);
	// email
	$to      = $current_user->user_email;
	$subject = mgk_get_setting('locked_mail_subject');
	$message = mgk_get_setting('locked_mail_message');
	$url     = add_query_arg(array('mgk_activate'=>$key), site_url());	
	$link    = sprintf('<a href="%s">%s</a>', $url, $url);
	$message = str_replace('[activation_link]',$link, $message);
	$message = str_replace('[name]',$current_user->display_name, $message);

	//set key
	if( update_user_meta($current_user->ID, 'mgk_activation_key', $key) ){
		// mail to user
		mgk_mail($to, $subject, $message);
	}	

	// mgk_pr($current_user); die;
}

/**
 * check activate account
 *
 * @param void
 * @return void
 */
function mgk_check_activate_account() {
	global $wpdb;

	//mgk_pr($_GET);

	if (mgk_get_var('mgk_activate')) {
	
		$sql = "SELECT `user_id` FROM `" . $wpdb->usermeta . "` WHERE `meta_key` = 'mgk_activation_key'
			    AND meta_value = '" . mysql_real_escape_string(mgk_get_var('mgk_activate')) . "'";
		    
		// check
		if ($user_id = $wpdb->get_var($sql)) {
			// update locked
			delete_user_meta($user_id, 'mgk_locked_out');
			// delete key
			delete_user_meta($user_id, 'mgk_activation_key');

			// redirect
			if ( $redirect = mgk_get_setting('activation_url') ) {
				echo sprintf('<script language="javascript">document.location.href="%s";</script>', $redirect);
			}
		}
	}
}

/**
 * user last ip
 *
 * @param boolean $user id
 * @return int
 */
function mgk_user_last_ip($user_id=false) {
	global $wpdb;
		
	$return = false;

	if (!$user) {
		// get current user
		$current_user = wp_get_current_user();
		// set id
		$user_id = $current_user->ID;
	}

	if ($user_id) {

		$sql = 'SELECT `ip_address`	FROM `' . MGK_TBL_USER_IPS . '` WHERE `user_id` = "' . $user_id . '"
				ORDER BY `access_dt` DESC LIMIT 1';
		$return = $wpdb->get_var($sql);
	}

	return $return;
}

/**
 * user last login
 *
 * @param string $user
 * @return string
 */
function mgk_user_last_login($user=false) {
	global $user_ID, $wpdb;

	if (!$user) {
		$user = $user_ID;
	}

	if ($user) {
		$time = false;

		$sql = 'SELECT `ip_address`, `access_dt`	FROM `' . MGK_TBL_USER_IPS . '`	WHERE `user_id` = '.$user.'
				ORDER BY `access_dt` DESC LIMIT 1';
		if ($r = $wpdb->get_row($sql)) {
			$time = date(mgk_get_setting('short_date_format'), strtotime($r->access_dt));
		}
	}

	return $time;
}

/**
 * requested variable
 *
 * @param string $key
 * @param string $default
 * @param boolean $strip_tags
 * @return string
 */
function mgk_request_var($key, $default='', $strip_tags=false) {
	if (isset($_POST[$key])) {
		$default = $_POST[$key];

		if ($strip_tags) {
			$default = strip_tags($default);
		}
	}

	return $default;
}

/**
 * post variable
 * 
 * @param string $key
 * @param string $default
 * @param boolean $strip_tags
 * @return string
 */
function mgk_post_var($key, $default='', $strip_tags=false) {
	if (isset($_POST[$key])) {
		$default = $_POST[$key];

		if ($strip_tags) {
			$default = strip_tags($default);
		}
	}

	return $default;
}

/**
 * get variable
 * 
 * @param string $key
 * @param string $default
 * @param boolean $strip_tags
 * return string
 */
function mgk_get_var($key, $default='', $strip_tags=false) {
	if (isset($_GET[$key])) {
		$default = $_GET[$key];

		if ($strip_tags) {
			$default = strip_tags($default);
		}
	}

	return $default;
}

/**
 * get_jquery_ui_versions
 *
 * @param void
 * @return void
 */
function mgk_get_jquery_ui_versions(){
	// read
	$_versions = glob(MGK_ASSETS_DIR . implode(MGK_DS, array('js','jquery','jquery.ui')) . MGK_DS . 'jquery-ui-*.js');	
	// init
	$versions = array('1.7.2','1.7.3','1.8.2');
	// check
	if($_versions){
		// loop
		foreach($_versions as $_version){
			// trim
			$versions[] = str_replace(array('jquery-ui-','.min.js'), '', basename($_version));
		}
	}	
	// return 
	return array_unique($versions);	
}

/**
 * get table names
 *
 * @param void
 * @return void
 */
function mgk_get_tables(){
	// init
	$tables = array();
	// constants
	$constants = get_defined_constants();		
	// loop
	foreach($constants as $constant=>$value){
		// match
		if(preg_match('/^MGK\_TBL\_/',$constant)){
			// not the prefix
			if( MGK_TABLE_PREFIX != $value){
				$tables[] = $value;
			}
		}
	}
	// return
	return $tables;
}

/**
 * find and update table field collation
 *
 * @param void
 * @return boolean
 */
function mgk_reset_tables_collate(){
	global $wpdb;
	// charset
	$charset = ( ! empty($wpdb->charset) ) ? $wpdb->charset : 'utf8';
	// collate
	$collate = ( ! empty($wpdb->collate) ) ? $wpdb->collate : 'utf8_general_ci';	
	// sql
	$sql_regx = 'ALTER TABLE `%s` CHANGE `%s` `%s` %s CHARACTER SET %s COLLATE %s %s;';
	// loop
	foreach (mgk_get_tables() as $table){				
		// query
		$fields = $wpdb->get_results(sprintf('SHOW FULL COLUMNS FROM `%s`',$table), ARRAY_A); 		
		// loop
		foreach($fields as $field){
			// check			
			if(isset($field['Collation'])){	
				// check
				if(!empty($field['Collation']) && $field['Collation'] != $collate){													
					// null
					$null = ($field['Null'] == 'NO') ? 'NOT NULL' : 'NULL DEFAULT NULL';	  	
					// sql 						
					$sql = sprintf($sql_regx, $table, $field['Field'], $field['Field'], $field['Type'], $charset, $collate, $null);					
					// update 	
					$wpdb->query($sql);						 
				}
			}
		}			
	} 		
	// return
	return true;
}

/**
 * get charset collate
 *
 * @param void
 * @return void
 */
function mgk_get_charset_collate(){
	global $wpdb;

	$charset_collate = '';

	if ( ! empty($wpdb->charset) )
		$charset_collate = "DEFAULT CHARACTER SET {$wpdb->charset}";
	if ( ! empty($wpdb->collate) )
		$charset_collate .= " COLLATE {$wpdb->collate}";
	
	// return	
	return $charset_collate;	
}
/**
 * returns timezone formatted current server date/timestamp
 *
 * @param string $format (date format) "Y-m-d" or "Y-m-d H:i:s"
 * @return array
 */
function mgk_get_current_datetime($format = 'Y-m-d', $format_timestamp = true) {
	// init
	$return = array();
	// get mysql time
	$timestamp = strtotime(current_time('mysql', 1));		
	// format:
	$return['date'] = date($format, $timestamp);
	// get formatted timestamp
	$return['timestamp']= $format_timestamp ? strtotime($return['date']) : $timestamp;	
	// return
	return $return; 
}
/**
 * return setting: MGK_DATE_FORMAT_INPUT to mysql format
 *
 * @param string $date
 * @return string: mysql date(Y-m-d)
 */
function mgk_format_inputdate_to_mysql($date, $format = null) {
	$delimiters = array(',', '\/', '-', ' ', ';');
	$delimiter = $date_delimiter = $format_delimiter = '/';
	
	if(is_null($format))
		$format = MGK_DATE_FORMAT_INPUT;
	
	foreach ($delimiters as $d) {
		//find delimiter in date
		if(preg_match("/$d/", $date)){
			$date_delimiter = stripslashes($d);			
		}
		//find delimiter in format
		if(preg_match("/$d/", $format)){
			$format_delimiter = stripslashes($d);		
		}
	}
	
	$date_splitted = explode($date_delimiter, $date);	
	$format_splitted = explode($format_delimiter, $format);
	
	foreach ($format_splitted as $key => $fs) {
		$fs = trim($fs);
		switch (strtolower($fs)) {
			case 'y':
			case 'yy':
			case 'yyyy':
				$year = isset($date_splitted[$key]) ? $date_splitted[$key]: '';
				break;
			case 'm':
			case 'mm':
				$month = isset($date_splitted[$key]) ? $date_splitted[$key]: '';
				break;	
			case 'd':
			case 'dd':
				$day = isset($date_splitted[$key]) ? $date_splitted[$key]: '';
				break;	
		}
	}	

	//return mysql std date format Y-m-d
	if(isset($year) && isset($month) && isset($day)) {
		$year 	= substr($year, 0, 4);
		$month 	= substr($month, 0, 2);			
		$day 	= substr($day, 0, 2);
		
		return $year.'-'.$month.'-'.$day;
	}
		
	return false; 	
}
/**
 * get calendar year range
 */
function mgk_get_calendar_year_range(){
	// ranges
	$range_lower = mgk_get_setting('date_range_lower');
	$range_upper = mgk_get_setting('date_range_upper');	
	// defaults
	if(!$range_lower) $range_lower = 50;
	if(!$range_upper) $range_upper = 10;
	
	// return 
	return sprintf('-%d:+%d',$range_lower,$range_upper);	
}
/**
 * check the given date is in mysql format
 */
function mgk_is_mysql_dateformat($date) {
	$date = trim(str_replace("00:00:00", '', $date));
	$arr_date = explode('-', $date);	
	if(isset($arr_date[2]) && strlen($arr_date[0]) == 4 && strlen($arr_date[1]) == 2 && strlen($arr_date[2]) == 2) {		
		return true;
	}else 
		return false;	
}
/**
 * convert MGK_DATE_FORMAT_INPUT to date picker format/date value to input field format(MGK_DATE_FORMAT_INPUT)
 * MGK_DATE_FORMAT_INPUT will always be fixed as we accept only numeric date value from input fields
 *
 */
function mgk_get_datepicker_format($type = 'format', $date = null) {

	$short_format = MGK_DATE_FORMAT_SHORT;
	$input_format = $short_format;
	if($type == 'format') {		
		//formats supported by jQuery datepicker:
		$delimiters = array(',', '\/', '-', ' ', ';');
		$delimiter = '/';		
		foreach ($delimiters as $d) {
			if(preg_match("/$d/", $input_format)){
				$delimiter = stripslashes($d);
			}
		}
				
		$format_splitted = explode($delimiter, $input_format);		
		foreach ($format_splitted as $key => $fs) {
			$fs = trim($fs);
			switch ($fs) {
				//year
				case 'y':
					$arr_format[] = $fs;
					break;	
				case 'Y':
					$arr_format[] = 'yy';								
					break;
				//month	
				case 'F':
					$arr_format[] = 'MM';
					break;
				case 'm':
					$arr_format[] = 'mm';	
					break;	
				case 'M':
					$arr_format[] = 'M';	
					break;
				case 'n':
					$arr_format[] = 'm';	
					break;	
				//day						
				case 'd':
					$arr_format[] = 'dd';
					break;	
				case 'D':
					$arr_format[] = 'D';
					break;	
				case 'j':
					$arr_format[] = 'd';
					break;	
				case 'l':
					$arr_format[] = 'DD';
					break;			
			}
		}
		if(count($arr_format) < 3)
			$arr_format = array(0 > 'm', 1 => 'd', 2 => 'Y');
			
		return implode($delimiter, $arr_format);
			
	}elseif ($type == 'date' && !is_null($date)) {				
		if (mgk_is_mysql_dateformat($date)) {			
			$conv_date = date( $input_format, strtotime( $date ) ); 			
		}else {//backward compatibility - convert all the previously saved dates to mysql format			
			$date = mgk_format_inputdate_to_mysql($date);			
			$conv_date = date( $input_format, strtotime( $date ) );			
		}
		
		return $conv_date;
	}
}

/**
 * compare wp version
 * @since 1.7.0
 */
function mgk_compare_wp_version($version = '3.1', $operator = '<'){
	global $wp_version;
	// return
	return (version_compare($wp_version, $version, $operator));
}

/**
 * compare ma version
 * @since 1.7.0
 */
function mgk_compare_version($version = '1.7.0', $operator = '<'){
	// version
	$mgk_version = get_option( 'mgk_version' );
	// return
	return (version_compare($mgk_version, $version, $operator));
}

/**
 * set admin ajax action
 * @since 1.7.0
 */
function mgk_admin_ajax_url($path=''){
	return 'admin-ajax.php?action=mgk_admin_ajax_action' . $path;
}
// end of file