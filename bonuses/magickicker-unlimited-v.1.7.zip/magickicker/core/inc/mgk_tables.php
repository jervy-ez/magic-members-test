<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
// db ref
global $wpdb;
// prefix
define('MGK_TABLE_PREFIX'        , 'mgk_'); 
// define tables constants
define('MGK_TBL_BLOCKED_IPS'   , $wpdb->prefix . MGK_TABLE_PREFIX . 'blocked_ips');
define('MGK_TBL_USER_IPS'      , $wpdb->prefix . MGK_TABLE_PREFIX . 'user_ips'); 
define('MGK_TBL_ACCESSED_URLS' , $wpdb->prefix . MGK_TABLE_PREFIX . 'accessed_urls');