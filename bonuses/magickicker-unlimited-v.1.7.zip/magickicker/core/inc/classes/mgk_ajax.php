<?php
// ajax class
class mgk_ajax{
	var $is_ajax=false; 
	// constructor
	function mgk_ajax(){
		// check if ajax
		$this->is_ajax=(isset($_SERVER["HTTP_X_REQUESTED_WITH"]) && $_SERVER["HTTP_X_REQUESTED_WITH"]  == 'XMLHttpRequest')?TRUE:FALSE;
	}	
	// check if ajax
	function is_ajax(){
		return $this->is_ajax;
	}	
	// header
	function send_header(){
		if(preg_match('#application/json#',$_SERVER['HTTP_ACCEPT'])){
			@header("Content-type:application/json");	
		}else if(preg_match('#text/javascript#',$_SERVER['HTTP_ACCEPT'])){
			@header("Content-type:text/javascript");	
		}else if(preg_match('#text/plain#',$_SERVER['HTTP_ACCEPT'])){
			@header("Content-type:text/plain");	
		}else{
			@header("Content-type:text/html");	
		}	
	}
	// start output
	function Start_Output($header=true){
	  if($this->is_ajax){
		ob_end_clean();
		if(!headers_sent()){
			$this->send_header();	
		}
		return true;
	  }
	}
	// end output
	function end_output(){
	  if($this->is_ajax){
		ob_end_flush();
		exit();
	  }
	}
	// build output
	function build_output($options=false, $load=NULL){	
		// cgi bug, load twice for cgi servers
		if( mgk_is_cgi_server() ){						
			mgk_set_include_path();
		}		
		// ajax call
		if( $this->is_ajax ){
			// load
			if( ! $load ) $load = isset($_GET['load']) ? $_GET['load'] : 'index' ;   
			// check  
			if(isset($load) && !empty($load)){
				// filter
				$options=$this->filter_options($options);
				// page
				$page = $options['prefix'] . $load . $options['extension'];// mgk_dashboard.tpl.php
				// start
				$this->Start_Output();	
				// require		
				if(file_exists(MGK_CORE_DIR . $options['container'] . DIRECTORY_SEPARATOR . $page)){					
					@require_once(MGK_CORE_DIR . $options['container'] . DIRECTORY_SEPARATOR . $page);
				}else{
					printf( 'File [%s] could not be loaded.', ($options['container'] . DIRECTORY_SEPARATOR . $page) );
				}
				// end
				$this->end_output();
			}
		}
	}
	// options
	function filter_options($options){
		$d_options=array('container'=>implode(DIRECTORY_SEPARATOR, array('admin','html')),'extension'=>'.tpl.php','prefix'=>'mgk_');
		if(is_array($options)){
			$d_options=array_merge($d_options,$options);
		}
		// send
		return $d_options;
	}
}
// end of file