<form id="accesslogsfrm" name="accesslogsfrm" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=members_list" method="post"> 
	<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table widefat" id="search-table">
		<tbody>
			<tr>
				<td>
					<?php _e('Search By','mgk')?>: 		
					<select name="search_field_name" style="width:150px">
						<?php echo mgk_make_combo_options($data['search_fields'],$data['search_field_name'],MGK_KEY_VALUE);?>
					</select>
					<span id="fld_wrapper">
						<input type="text" name="search_field_value" value="<?php echo $data['search_field_value']?>">
					</span>					
					<span id="fld_wrapper_two">
						<input type="text" name="search_field_value_two" value="<?php echo $data['search_field_value_two']?>">
					</span>			
				</td>
				<td>		
					<?php _e('Sort By','mgk')?>: 
					<select name='sort_field_name' class='width135px'>					
						<?php echo mgk_make_combo_options($data['sort_fields'], $data['sort_field'], MGK_KEY_VALUE);?>
					</select>		
					<select name='sort_type'>					
						<?php echo mgk_make_combo_options(array('desc'=>'DESC','asc'=>'ASC'), $data['sort_type'], MGK_VALUE_ONLY);?>
					</select>		
				</td>
				<td>
					<input type="button" name="show_accesslogs_btn" class="button" value="<?php _e('Show','mgk') ?>" onclick="mgk_show_accesslogs_list(true)" />		
				</td>
				<td><a href="javascript:mgk_reload_accesslogs()"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/arrow_refresh.png" /></a></td>			
			</tr>
		</tbody>
	</table>
</form>
<script language="javascript">
	jQuery(document).ready(function(){
		// change search field
		var onchange_count = 0;
		var search_val     = '<?php echo (isset($data['search_field_value'])) ? $data['search_field_value'] : ''?>';	
		var search_val2    = '<?php echo (isset($data['search_field_value_two'])) ? $data['search_field_value_two'] : ''?>';
		// bind	search field change		
		jQuery("select[name='search_field_name']").bind('change',function() {
				// remove old		
				jQuery(":input[name='search_field_value']").remove();		
				// reset val
				if(onchange_count > 0) search_val = search_val2 = '';
				// on val
				switch(jQuery(this).val()){
					case 'access_dt':						
					jQuery('#fld_wrapper').html('<input type="text" name="search_field_value" value="'+search_val+'" size="8">');
						if(!jQuery("#accesslogsfrm :input[name='search_field_value']").hasClass('hasDatepicker')){					
							mgk_date_picker("#accesslogsfrm :input[name='search_field_value']",'<?php echo MGK_ASSETS_URL?>', {yearRange:"<?php echo mgk_get_calendar_year_range(); ?>", dateFormat: "<?php echo mgk_get_datepicker_format()?>"});
						}
						jQuery('#fld_wrapper_two').html('<input type="text" name="search_field_value_two" value="'+search_val2+'" size="8">');
						if(!jQuery("#accesslogsfrm :input[name='search_field_value_two']").hasClass('hasDatepicker')){					
							mgk_date_picker("#accesslogsfrm :input[name='search_field_value_two']",'<?php echo MGK_ASSETS_URL?>', {yearRange:"<?php echo mgk_get_calendar_year_range(); ?>", dateFormat: "<?php echo mgk_get_datepicker_format()?>"});
						}	
					break;					
				default:					
					jQuery('#fld_wrapper_two').html('');
					jQuery('#fld_wrapper').html('<input type="text" name="search_field_value" value="'+search_val+'" size="20">');
					break;
				}
				onchange_count++;
			}).change();
	});
</script>