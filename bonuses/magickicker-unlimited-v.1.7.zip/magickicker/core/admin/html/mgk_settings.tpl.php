<?php  if ( !defined('ABSPATH') ) exit('No direct script access allowed');

/**
 * Admin Module
 *
 * @package WordPress
 * @subpackage magickicker
 * @since 1.0	
 */
 
// get flag
$action_flag=(isset($_REQUEST['mode'])) ? $_REQUEST['mode']: 'index';
// call process
mgk_call_process($action_flag);

/**
 * default tabs
 *
 * @param void
 * @return void
 */
function f_tabs(){
	?>
	<div id="wrap-admin-settings" class="content-div">
		<ul class="tabs">			
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=general"><span class="pngfix"><?php _e('General','mgk')?></span></a></li>																				
			<!--<li><a href="aadmin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=emailtemplates"><span class="pngfix"><?php _e('Email Templates','mgk')?></span></a></li>-->
		</ul>										
	</div>	
	<?php
}

/**
 * default list
 *
 * @param void
 * @return void
 */
function f_index(){	
	f_general();		
}

/**
 * general
 *
 * @param void
 * @return string
 */
function f_general(){
	global $wpdb;
	// save
	if(isset($_POST['process']) && $_POST['process']=='true'){		
		extract($_POST);
		if(isset($settings)){
			// check email unique
			$old_settings=get_option('mgk_settings');
			if(is_array($old_settings)){
				$new_settings=array_merge($old_settings,$_POST['settings']);
			}else{
				$new_settings=$_POST['settings'];
			}
			update_option('mgk_settings', $new_settings);
			// message				
			$status  ='success';
			$message =__('General Settings updated successfully','mgk');		
		}else{
			$status  ='error';
			$message =__('Setting not provided','mgk');
		}		
		// the response
		echo json_encode(array('status'=>$status,'message'=>$message));
		exit();
	}
	// old settings
	$mgk_settings = get_option('mgk_settings');
	$settings     = $mgk_settings['general'];	
	
	// $membershipmods = mgk_get_setting('membership','recurringmodules');
	
	// show form
	?>
	<?php mgk_box_top('General Settings')?>	
	<form name="frmgenset" id="frmgenset" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=general">
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table">		
			<tbody>
				<tr>
					<td valign="top"><b><?php _e('Force logout URL','mgk')?></b></td>
				</tr>
				<tr>	
					<td valign="top">
						<input type="text" name="settings[general][redirect_url]" size="80" value="<?php echo $settings['redirect_url']?>"/>
						<div class="tips"><?php _e('This is where the user is sent when their ip address is not the same as the one they previously logged in from.','mgk')?></div>						
					</td>
				</tr>
				<tr>
					<td valign="top"><b><?php _e('Multiple Login Lockout Condition','mgk')?></b></td>
				</tr>
				<tr>	
					<td valign="top">
						<input type="text" name="settings[general][timeout_logins]" size="10" value="<?php echo $settings['timeout_logins']?>"/> <?php _e('Logins over', 'mgk')?>
						<input type="text" name="settings[general][timeout_minutes]" size="10" value="<?php echo $settings['timeout_minutes']?>"/> <?php _e('Minutes', 'mgk')?>
						<div class="tips"><?php _e('The number of minutes between logins from multiple ip addresses that have to pass without both accounts being locked out.','mgk')?></div>						
					</td>
				</tr>
				<tr>
					<td valign="top"><b><?php _e('Lockout or Logout','mgk')?></b></td>
				</tr>
				<tr>	
					<td valign="top">
						<input type="radio" name="settings[general][lockout_option]" value="lockout" <?php echo mgk_check_if_match('lockout', $settings['lockout_option'],'lockout')?> onclick="mgk_toggle_lo_options('lockout');"/> <?php _e('Lockout', 'mgk');?>
						<input type="radio" name="settings[general][lockout_option]" value="logout" <?php echo mgk_check_if_match('logout',$settings['lockout_option'])?> onclick="mgk_toggle_lo_options('logout');"/> <?php _e('Logout', 'mgk');?>		
						<div class="tips"><?php _e('This gives you the option to log the user out on a breach or lock them out completely.','mgk')?></div>						
					
						<div id="lockout_options_div" style="display:<?php echo ($settings['lockout_option'] == 'lockout' ? 'block':'none') ?>;">
							<table width="100%" cellpadding="1" cellspacing="0" border="0">
								<tr>
									<td valign="top"><b><?php _e('Locked Out Login Error', 'mgk')?></b></td>
								</tr>
								<tr>	
									<td valign="top">
										<input type="text" name="settings[general][login_error]" value="<?php echo $settings['login_error']?>" style="width: 450px;" />									
										<div class="tips"><?php _e('The message that is shown to the user on login when they have been locked out.', 'mgk')?></div>
									</td>
								</tr>								
								<tr>
									<td valign="top"><b><?php _e('Email Activation or Timed lockout', 'mgk')?></b></td>
								</tr>
								<tr>	
									<td valign="top">										
										<input type="radio" name="settings[general][email_offender]" value="email" <?php echo mgk_check_if_match('email', $settings['email_offender'],'email')?> onclick="mgk_toggle_eo_options('email'); "/> <?php _e('Email', 'mgk');?>									
										<input type="radio" name="settings[general][email_offender]" value="timed" <?php echo mgk_check_if_match('timed', $settings['email_offender'])?> onclick="mgk_toggle_eo_options('timed');"/> <?php _e('Timed', 'mgk');?>								
										<div class="tips"><?php _e('Would you like to notify the owner of the account via email in the event of a breach or lock them out for a number of minutes?', 'mgk')?></div>
									</td>
								</tr>
							</table>	
						</div>
						
						<div id="lockout_mins_div" style="display:<?php echo ($settings['lockout_option'] == 'lockout' && $settings['email_offender'] == 'timed' ? 'block':'none') ?>;">
							<table width="100%" cellpadding="1" cellspacing="0" border="0">
								<tr>
									<td valign="top"><b><?php _e('Lockout Minutes', 'mgk');?></b></td>
								</tr>
								<tr>	
									<td valign="top">
										<input type="text" name="settings[general][lockout_minutes]" value="<?php echo $settings['lockout_minutes']?>" style="width: 50px;" /> <?php _e('Minutes', 'mgk');?>
										<br/>
										<div class="tips"><?php _e('If you selected the option to lock the user out for a period of time then how long should that be?', 'mgk');?></div>
									</td>
								</tr>
							</table>	
						</div>
						
						<div id="lockout_email_div" style="display:<?php echo ($settings['lockout_option'] == 'lockout' && $settings['email_offender'] == 'email' ? 'block':'none') ?>;">
							<table width="100%" cellpadding="1" cellspacing="0" border="0">
								<tr>
									<td valign="top"><b><?php _e('Email Subject', 'mgk');?></b></td>
								</tr>
								<tr>	
									<td valign="top">
										<input type="text" name="settings[general][locked_mail_subject]" value="<?php echo $settings['locked_mail_subject']?>" style="width: 350px;" />
									</td>
								</tr>		
								<tr>
									<td valign="top"><b><?php _e('Email Message', 'mgk');?></b></td>
								</tr>
								<tr>	
									<td valign="top">
										<textarea name="settings[general][locked_mail_message]" cols="40" rows="10" id="locked_mail_message" style="height:200px; width:800px"><?php echo $settings['locked_mail_message']?></textarea>
										<div class="tips"><?php _e('The email that is sent to the user of the account with the following hook in it [activation_link].', 'mgk');?></div>
									</td>
								</tr>		
								<tr>
									<td valign="top"><b><?php _e('Activation Redirect', 'mgk');?></b></td>
								</tr>
								<tr>	
									<td valign="top">
										<input type="text" name="settings[general][activate_redirect]" style="width: 350px;" value="<?php echo isset($settings['activate_redirect']) ? $settings['activate_redirect'] : ''?>" />
										<div class="tips"><?php _e('This is an optional redirect for the user once an accepted activation link has been processed. If this box is left empty then then it will not redirect.', 'mgk');?></div>
									</td>
								</tr>
							</table>	
						</div>
						
					</td>
				</tr>
				<tr>
					<td valign="top"><b><?php _e('Date Ranges:','mgk')?></b></td>
				</tr>
				<tr>				
					<td valign="top">
						<?php _e('Lower')?> : <input type="text" name="settings[general][date_range_lower]" value="<?php echo esc_html($settings['date_range_lower'])?>" size="6" maxlength="2"/> 
							<em>- <?php _e('current year','mgk')?> (<?php echo date('Y',strtotime('- '.(int)$settings['date_range_lower'].' YEAR'))?>)</em>									</td>
				</tr>
				<tr>				
					<td valign="top">
						<?php _e('Upper')?> : <input type="text" name="settings[general][date_range_upper]" value="<?php echo esc_html($settings['date_range_upper'])?>" size="6" maxlength="2"/> 
							<em>- <?php _e('current year','mgk')?> (<?php echo date('Y',strtotime('- '.(int)$settings['date_range_upper'].' YEAR'))?>)</em>									</td>
				</tr>				
				<tr>	
					<td valign="top">		
						<div class="tips"><?php _e('Date lower and upper range in all calendar popup','mgk')?></div>						
					</td>
				</tr>														
				<tr>
					<td valign="top"><b><?php _e('Long date Format','mgk')?></b></td>
				</tr>
				<tr>	
					<td valign="top">
						<select name="settings[general][long_date_format]" >
							<option value="m-d-Y h:i:s" <?php mgk_select_if_match('m-d-Y h:i:s',$settings['long_date_format'],'m-d-Y h:i:s')?>><?php echo date('m-d-Y h:i:s')?></option>
							<option value="m-d-Y H:i:s" <?php mgk_select_if_match('m-d-Y H:i:s',$settings['long_date_format'])?>><?php echo date('m-d-Y H:i:s')?></option>
							
							<option value="jS F, Y h:i:s" <?php mgk_select_if_match('jS F, Y h:i:s',$settings['long_date_format'])?>><?php echo date('jS F, Y h:i:s')?></option>
							<option value="jS F, Y H:i:s" <?php mgk_select_if_match('jS F, Y H:i:s',$settings['long_date_format'])?>><?php echo date('jS F, Y H:i:s')?></option>
							
							<option value="jS M, Y h:i:s" <?php mgk_select_if_match('jS M, Y h:i:s',$settings['long_date_format'])?>><?php echo date('jS M, Y h:i:s')?></option>
							<option value="jS M, Y H:i:s" <?php mgk_select_if_match('jS M, Y H:i:s',$settings['long_date_format'])?>><?php echo date('jS M, Y H:i:s')?></option>							
						</select>			
						<div class="tips"><?php _e('Long Date Format for Display.','mgk')?></div>						
					</td>
				</tr>	
				<tr>
					<td valign="top"><b><?php _e('Pagination Limit','mgk')?></b></td>
				</tr>
				<tr>	
					<td valign="top">
						<input type="text" name="settings[general][pagination]" size="10" value="<?php echo $settings['pagination']?>"/>						
						<div class="tips"><?php _e('Admin Pagination Limit.','mgk')?></div>
					</td>
				</tr>		
				<tr>
					<td valign="top">
						<input type="submit" name="btn_save" value="<?php _e('Save','mgk')?>" class="button"/>						
					</td>
				</tr>
			</tbody>	
		</table>	
		<input type="hidden" name="process" value="true" />
	</form>											
	<br />	
	<?php mgk_box_bottom()?>
	<br />
	<?php mgk_box_top('Remove Magic Kickers')?>	
	<form name="frmgenuni" id="frmgenuni" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=remove_plugin">
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table">		
			<tbody>
				<tr>
					<td>
						<p><?php _e('<strong>Warning!</strong> This will remove all Magic Kickers data including sales records.','mgk') ?></p>
						<p><strong><?php _e('Back up before removal! Once done this can not be undone!','mgk') ?></strong></p>
					</td>
				</tr>
				<tr>					
					<td valign="top">
						<input type="button" name="removebtn" value="<?php _e('Remove All Data','mgk') ?>" class="button" onclick="remove_mgk(this)"/>						
					</td>
				</tr>
				<tr>
					<td>
						<p><?php _e('Only use this tool if you really mean to permanently remove Magic Kickers, otherwise deactivate/activate using the normal Plugin screen','mgk') ?></p>
					</td>
				</tr>
			</tbody>
		</table>
		<?php wp_nonce_field( 'deactivate_plugin_magickicker', 'deactivate_plugin_magickicker', false );?>	
	</form>		
	<br />	
	<?php mgk_box_bottom()?>
	<br />
	<?php mgk_box_top('Setup Environment for Magic Kickers')?>	
	<form name="frmgenenv" id="frmgenenv" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=env_setup">
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table">		
			<tbody>
				<tr>
					<td><b><?php _e('Please Select a jQueryUI version :','mgk')?></b></td>
				</tr>
				<tr>
					<td>						
						<select name="jqueryui_version" style="width:150px">
							<?php echo mgk_make_combo_options(mgk_get_jquery_ui_versions(), get_option('mgk_jqueryui_version'), MGK_VALUE_ONLY)?>
						</select>
						<div class="information"><?php _e('jQuery UI version to use, for best performance, version 1.8.2 is recommended if that works with your WP environment.','mgk')?></div>
					</td>
				</tr>
				<tr>
					<td><b><?php echo __('Disable Core jQuery On Site:','mgk')?></b></td>
				</tr>
				<tr>
					<td>
						<input type="checkbox" name="disable_core_jquery" value="Y"  <?php echo (get_option('mgk_disable_core_jquery') == 'Y') ? 'checked' : '';?>/> <?php _e('Yes','mgk')?>
						<div class="information"><?php _e('Easy way to solve jQuery clash problem i.e. with Thesis Theme. Only stop jQuery on Theme/Site.','mgk'); ?></div>						
					</td>
				</tr>
			</tbody>
			<tfoot>	
				<tr>
					<td height="10px">
						<p>	
							<input type="button" class="button" onclick="mgk_env_setup()" value="<?php _e('SETUP &raquo;','mgk') ?>"/>
						</p>
					</td>
				</tr>	
			</tfoot>
		</table>		
		<input type="hidden" name="process" value="true" />
	</form>		
	<br />	
	<?php mgk_box_bottom()?>	
	<script language="javascript">
	<!--
		// onready
		jQuery(document).ready(function(){   						
			// first field focus 	
			jQuery("#frmgenset :input:first").focus();				
			// editor	
			jQuery("#frmgenset textarea[id]").each(function(){
				new nicEditor({fullPanel : true, iconsPath: '<?php echo MGK_ASSETS_URL?>js/nicedit/nicEditorIcons.gif'}).panelInstance(jQuery(this).attr('id')); 					
			});				
			// add login form validation
			jQuery("#frmgenset").validate({					
				submitHandler: function(form) {					    					
					jQuery("#frmgenset").ajaxSubmit({type: "POST",
					  url: 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=general',
					  dataType: 'json',	
					  iframe: false,
					  beforeSerialize: function($form) { 					
						// only on IE
						if(jQuery.browser.msie){
							jQuery($form).find("textarea[id]").each(function(){								
								jQuery(this).val(nicEditors.findEditor(jQuery(this).attr('id')).getContent()); 
							});										
						}
					  },										 
					  beforeSubmit: function(){	
					 	// message
					  	mgk_show_message('#wrap-admin-settings', {status: 'running', message: '<?php _e('Saving...','mgk');?>'}, true);														  	
					  },
					  success: function(data){	
					  	// message
					  	mgk_show_message('#wrap-admin-settings', data);													   	
					  }});    		
					return false;											
				},
				rules: {			
					'settings[general][redirect_url]': "required",
					'settings[general][timeout_logins]': {required:true,digits:true},
					'settings[general][timeout_minutes]': {required:true,digits:true},
					'settings[general][lockout_option]': "required"
				},
				messages: {			
					'settings[general][redirect_url]': "<?php _e('Please enter logout url','mgk')?>",
					'settings[general][timeout_logins]': "<?php _e('Please enter login lockout logins','mgk')?>",					
					'settings[general][timeout_minutes]': "<?php _e('Please enter login lockout minutes','mgk')?>",
					'settings[general][lockout_option]': "<?php _e('Please select lockout option','mgk')?>"
				},	
				errorClass: 'validation-error',
				errorPlacement: function(error, element) {
					if(element.is(":input[name^='settings[general]']"))						
						element.parent().append( error );										
					else							
						error.insertAfter(element);
				}
			});					
			
			// remove
			remove_mgk=function(e){
				// confirm
				if(!confirm('<?php _e('Are you sure you want to remove all Magic Kicker data?','mgk')?>')) 
					return;					
				
				// process
				jQuery("#frmgenuni").ajaxSubmit(
					{type: "POST",
					url: 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=remove_plugin',
					dataType: 'json',											 
					beforeSubmit: function(){	
						// message
						mgk_show_message('#wrap-admin-settings', {status: 'running', message: '<?php _e('Processing...','mgk');?>'}, true);																  	
					},
					success: function(data){	
						// message
						mgk_show_message('#wrap-admin-settings', data);	
						// success
						if(data.status=='success' && data.redirect != ''){														
							window.location.href = data.redirect;
						}													   	
					}
				}); 
			}		
				
			// mgk_env_setup	
			mgk_env_setup = function(){				
				jQuery('#frmgenenv').ajaxSubmit({
					dataType: 'json',											 
					beforeSubmit: function(){	
						// show message
						mgk_show_message('#frmgenenv', {status:'running', message:'<?php _e('Processing...','mgk')?>'},true);						
					},
					success: function(data){	
						// message																				
						mgk_show_message('#frmgenenv', data);		
					
						// success	
						if(data.status=='success' && data.redirect != ''){																													
						// redirect							
							window.location.href = data.redirect;																	
						}	
					}
				});				
			}
						
			// toggle
			mgk_toggle_lo_options =function(s){
				if(s=='lockout'){
					jQuery('#lockout_options_div').slideDown();
				}else{
					jQuery('#lockout_options_div').slideUp();	
				}	
			}
			
			// toggle
			mgk_toggle_eo_options=function(s){
				if(s=='timed'){
					jQuery('#lockout_mins_div').slideDown();
					jQuery('#lockout_email_div').slideUp();
				}else{
					jQuery('#lockout_email_div').slideDown();
					jQuery('#lockout_mins_div').slideUp();	
				}	
			}
			
		});	
	//-->		
	</script>
	<?php
}

/**
 * remove plugin
 *
 * @param void
 * @return string
 */
function f_remove_plugin(){
	$plugin = trim('magickicker/magickicker.php');
	if (is_plugin_active($plugin)) {
		// deactivate first
		deactivate_plugins($plugin, true);
		// remove all
		mgk_deactivate(true);
		// redirect
		$status   ='success';
		$message  =__('Plugin deactivated','mgk');
		$redirect ='plugins.php?deactivate=true&plugin_status=active&paged=1'; 
	}else{
		$status  ='error';
		$message =__('Plugin already deactivated','mgk');
	}	
	// response
	echo json_encode(array('status'=>$status,'message'=>$message,'redirect'=>$redirect));
}

/**
 * mgk_env_setup
 *
 * @param void
 * @return string
 */
function f_env_setup(){
	// save
	if(isset($_POST['process']) && $_POST['process']=='true'){		
		extract($_POST);		
		// message				
		$status   ='success';
		$message  =__('Environment setup completed successfully.','mgk');	
		$redirect = 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin'; 	
		// update		
		update_option('mgk_jqueryui_version', $_POST['jqueryui_version']);
		update_option('mgk_disable_core_jquery', $_POST['disable_core_jquery']);		
		// the response
		echo json_encode(array('status'=>$status,'message'=>$message,'redirect'=>$redirect));
		exit();
	}		
	// echo json_encode(array('status'=>$status,'message'=>$message));
}
// end of file