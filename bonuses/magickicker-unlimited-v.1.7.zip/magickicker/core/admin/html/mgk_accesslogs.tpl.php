<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
/**
 * Access Log Admin 
 *
 * @package WordPress
 * @subpackage magickicker
 * @since 1.0	
 */
 
// get flag
$action_flag=(isset($_REQUEST['mode'])) ? $_REQUEST['mode']: 'index';
// call process
mgk_call_process($action_flag);

/**
 * default tabs
 *
 * @param void
 * @return void
 */
function f_tabs(){
	?>
	<div id="wrap-admin-accesslogs" class="content-div">
		<ul class="tabs">			
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=members"><span class="pngfix"><?php _e('Members','mgk')?></span></a></li>										
		</ul>										
	</div>
	<?php
}

/**
 * default list
 *
 * @param void
 * @return void
 */
function f_index(){	
	f_members();		
}

/**
 * default: list of blocked members
 *
 * @param void 
 * @return string
 */
function f_members(){

	?>
	<?php mgk_box_top('Recently Logged Members')?>		
	<div id="accesslogs_list"></div>	
	<?php mgk_box_bottom()?>
	<script language="javascript">
		<!--
		// onready
		jQuery(document).ready(function(){  
			// set pager
			mgk_set_pager('#admin_accesslogs');
			// reload
			mgk_reload_accesslogs=function(){
				jQuery('#admin_accesslogs .content-div').tabs('load',0);
			}	
			// edit
			mgk_view_accessed_urls=function(id){			
				// create tab
				jQuery('#admin_accesslogs .content-div').mgkAutoTabs({index: 1, select: 1, label: '<?php _e('Accessed URLs','mgk')?>', url: 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=view_accessed_urls&id='+id});						
			}
			// show list, keep the last query
			mgk_show_accesslogs_list=function(m) {
				var _m = m || false;
				// post
				jQuery.ajax({url:'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=members_list', 
					type: 'POST', cache:false, data : jQuery("#search-table :input").serialize(),
					beforeSend: function(){	
						// show message
						mgk_show_message('#accesslogs_list', {status:'running', message:'<?php _e('Processing','mgk')?>...'},true);														
					 },
					 success:function(data){																																		
						// append 
						jQuery('#accesslogs_list').html(data);					
						// show message
						if(_m){
							mgk_show_message('#accesslogs_list', {status:'success', message: jQuery('#last_search_message').html() }, true);
						}else{
							mgk_hide_message('#accesslogs_list');
						}				 
					 }
				});
			}			
			mgk_show_accesslogs_list(false);
		});		
		//-->
	</script>
	<?php								
}

/**
 * default: list of blocked members
 *
 * @param void 
 * @return string
 */
function f_members_list(){
	global $wpdb;
	
	//data
	$data = array();	
	// search fields
	$data['search_fields'] = array(''=> __('Select','mgk'), 'id'=> __('User ID','mgk'), 'user_login'=> __('Username','mgk'), 
	                              'user_email'=> __('User Email','mgk'), 'ip_address' => __('IP Address','mgk'),
								  'access_dt'=> __('Access Date','mgk'));
	// sort fields							  
	$data['sort_fields'] = array( 'id'=> __('User ID','mgk'),'user_login'=> __('Username','mgk'), 'user_email'=> __('User Email','mgk'),
	                             'access_dt'=> __('Access Date','mgk'));								  
	// filter
	$sql_filter = $data['search_field_name'] = $data['search_field_value'] = '';	
	$search_field_name = mgk_post_var('search_field_name');
	
	// check
	if(!empty($search_field_name)) {
		// post
		$search_field_value     = mgk_post_var('search_field_value');
		$search_field_value_two = mgk_post_var('search_field_value_two');		
		// view data	
		$data['search_field_name'] 	    = $search_field_name;					
		$data['search_field_value']     = htmlentities($search_field_value, ENT_QUOTES, "UTF-8");
		$data['search_field_value_two'] = htmlentities($search_field_value_two, ENT_QUOTES, "UTF-8");
		// for sql				
		$search_field_value     = $wpdb->escape($search_field_value);
		$search_field_value_two = $wpdb->escape($search_field_value_two);
		//current date
		$curr_date = mgk_get_current_datetime();
		$current_date = $curr_date['timestamp'];		
		// by field
		switch($search_field_name){
			case 'id':
				$sql_filter = " AND A.ID = '".(int)$search_field_value."'";	
			break;
			case 'user_login':
				$sql_filter = " AND A.user_login LIKE '%{$search_field_value}%'";			
			break;
			case 'user_email':
				$sql_filter = " AND A.user_email LIKE '%{$search_field_value}%'";			
			break;
			case 'ip_address':
				$sql_filter = " AND B.ip_address = '".$search_field_value."'";		
			break;
			case 'access_dt':
				if(empty($search_field_value)){
					$search_field_value = date('Y-m-d',$current_date);
				}
				if(empty($search_field_value_two)){
					$search_field_value_two = date('Y-m-d',$current_date);
				}				
				// convert 
				$search_field_value = mgk_format_inputdate_to_mysql($search_field_value,MGK_DATE_FORMAT_SHORT);	
				$search_field_value_two = mgk_format_inputdate_to_mysql($search_field_value_two,MGK_DATE_FORMAT_SHORT);				
				$sql_filter = " AND DATE_FORMAT(B.access_dt,'%Y-%m-%d') BETWEEN '{$search_field_value}' AND '{$search_field_value_two}'";							
			break;										
		}					
	}

	// order
	$sql_order = $data['sort_field'] = $data['sort_type'] = '';
	// sort
	$sort_field_name = mgk_post_var('sort_field_name');
	$sort_type       = mgk_post_var('sort_type');

	// check
	if(isset($sort_field_name)){
		//issue#: 219
		$data['sort_field'] = $sort_field_name;
		$data['sort_type']  = $sort_type;
		// by name
		switch($sort_field_name){
			case 'id':
				//$sql_order_by = "A.ID";
				$sql_order_by = "B.user_id";
			break;
			case 'user_login':
				$sql_order_by = "A.user_login";
			break;
			case 'user_email':
				$sql_order_by = "A.user_email";
			break;
			case 'access_dt':
				$sql_order_by = "B.access_dt";
			break;
		}			
		// set
		if(isset($sql_order_by)) $sql_order = " ORDER BY {$sql_order_by} {$sort_type}";			
	}
	
	//check
	if(!isset($sql_order_by)) $sql_order = " ORDER BY B.access_dt DESC";
		
	// pager
	$pager = new mgk_pager();
	$limit = $pager->get_query_limit( mgk_get_setting('pagination') );
	// sql		  
	$sql = "SELECT SQL_CALC_FOUND_ROWS B.id, CONCAT('[#',A.ID,'] ',A.user_login,' (', A.user_email,')') AS user,
	        B.ip_address,B.access_dt, (SELECT COUNT(*) FROM `" . MGK_TBL_ACCESSED_URLS . "` WHERE `ip_id` = B.id) AS urls_count 
			FROM `{$wpdb->users}` A JOIN `" . MGK_TBL_USER_IPS . "` B ON (A.ID = B.user_id) WHERE 1 {$sql_filter} {$sql_order} {$limit}" ;
	// rows	
	$logged_users=$wpdb->get_results($sql);
	//echo $wpdb->last_query;
	$data['page_url'] = 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=members_list';
	// get page links
	$page_links=$pager->get_pager_links($data['page_url']);
	// total rows/results
	$data['row_count']  = $pager->get_row_count();
	// search term
	$search_term = '';
	// search provided
	if( !empty($data['search_field_value']) ){			
		if(!empty($data['search_field_value_two'])){
			$search_term = sprintf('where <b>%s</b> between <b>%s</b> and <b>%s</b> dates', 				
			(isset($data['search_fields'][$search_field_name]) ? $data['search_fields'][$search_field_name] : ''), 
			$data['search_field_value'],$data['search_field_value_two']);
		}else {
			$search_term = sprintf('where <b>%s</b> is <b>%s</b>', (isset($data['search_fields'][$search_field_name]) ? $data['search_fields'][$search_field_name] : ''), $data['search_field_value']);
		}			
	}	
	// message
	$data['message'] = sprintf(__('%d %s matched %s','mgk'), $data['row_count'], ($data['row_count']>1 ? 'members' : 'member'), $search_term);
	// format
	$date_long_format = mgk_get_setting('long_date_format');
	?>
	<span id="last_search_message" style="display:none;"><?php echo $data['message']?></span>
	<div align="center"><?php include_once('mgk_accesslogs_search_box.tpl.php'); ?></div>
	<div class="clearfix"></div>
	<div align="right"><?php if($page_links):?><div class="pager-wrap"><?php echo $page_links?></div><?php endif; ?></div>																
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table widefat">
			<thead>
				<tr>				
					<!--<th scope="col"><b>#<?php _e('ID','mgk')?></b></th>-->					
					<th scope="col"><b><?php _e('User','mgk');?></b></th>
					<th scope="col"><b><?php _e('IP Address','mgk');?></b></th>												
					<th scope="col"><b><?php _e('Access Date/Time','mgk');?></b></th>
					<th scope="col"><b><?php _e('Accessed URLs','mgk');?></b></th>											
					<th scope="col"><b><?php _e('Action','mgk');?></b></th>
				</tr>
			</thead>
			<tbody>
				<?php $alt=''; if(count($logged_users)==0):?>
				<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>" id="row-0">		
					<td colspan="4" align="center"><?php _e('There are currently no logged users.','mgk')?></td>
				</tr>
				<?php endif;						
				// show
				foreach ($logged_users as $log) :?>
				<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>" id="row-<?php echo $log->id?>">		
					<!--<td valign="top"><?php echo $log->id?></td>-->							
					<td valign="top"><?php echo $log->user?></td>
					<td valign="top"><?php echo $log->ip_address?></td>	
					<td valign="top"><?php echo (strtotime($log->access_dt) > 1) ? date($date_long_format, strtotime($log->access_dt)) : __('N/A', 'mgk')?></td>							
					<td valign="top"><?php echo $log->urls_count?></td>	
					<td valign="top" nowrap="nowrap">
						<a href="javascript:mgk_view_accessed_urls('<?php echo $log->id?>')" title="<?php _e('View accessed URLs','mgk')?>"><img src="<?php echo MGK_ASSETS_URL?>images/icons/server_link.png" /></a>							
					</td>
				</tr>
				<?php endforeach;?>					
			</tbody>	
		</table>			
		<div align="right"><?php if($page_links):?><div class="pager-wrap"><?php echo $page_links?></div><div class="clearfix"></div><?php endif; ?></div>	
		<script language="javascript">
			<!--
			jQuery(document).ready(function(){
				// set pager anchor 2 post
				mgk_set_pager_anchor2post('#accesslogs_list', '#search-table');
				// set pager dropdown 2 post
				mgk_set_pager_select2post('#accesslogs_list', '#search-table', '<?php echo $data['page_url']?>');							
			});
			//-->	
		</script>
	<?php								
}

/**
 * view accessed urls
 *
 * @param void 
 * @return string
 */
function f_view_accessed_urls(){	
	global $wpdb;
	// ip log id
	$id = (int)$_GET['id'];
	// sql		  
	$sql = "SELECT SQL_CALC_FOUND_ROWS CONCAT('[#',A.ID,'] ',A.user_login,' (', A.user_email,')') AS user,
	        B.ip_address,B.access_dt FROM `{$wpdb->users}` A JOIN `" . MGK_TBL_USER_IPS . "` B ON (A.ID = B.user_id)
			WHERE B.id='{$id}'" ;	
	// logged			 
	$logged_user = $wpdb->get_row($sql);
	// log
	// echo $sql;	
	// get all	
	/*$sql = "SELECT A.* FROM `" . MGK_TBL_ACCESSED_URLS . "` A JOIN `" . MGK_TBL_USER_IPS . "` B ON(A.ip_id=B.id) 
			  JOIN `{$wpdb->users}` C ON (C.ID = B.user_id) WHERE `ip_id` = '{$id}' ORDER BY `access_dt` ASC";*/
			
	$sql = "SELECT * FROM `" . MGK_TBL_ACCESSED_URLS . "` WHERE `ip_id` = '{$id}' ORDER BY `access_dt` ASC";			
	// fetch
	$accessed_urls = $wpdb->get_results($sql);
	
	// log
	// echo $sql;
	// mgk_pr($logged_user);
	// mgk_pr($accessed_urls);
	
	// format
	$date_long_format = mgk_get_setting('long_date_format');	
	// show form
	?>
	<?php mgk_box_top('Accessed URLs')?>	
	<form name="frmaccurlview" id="frmaccurlview" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs">
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table widefat">
			<tr>
				<td><?php _e('User','mgk')?></td>
				<td><?php echo $logged_user->user?></td>
			</tr>
			<tr>
				<td><?php _e('IP Address','mgk')?></td>
				<td><?php echo $logged_user->ip_address?></td>
			</tr>
			<tr>
				<td><?php _e('Access Date/Time','mgk')?></td>
				<td><?php echo (strtotime($logged_user->access_dt) > 1) ? date($date_long_format, strtotime($logged_user->access_dt)) : __('N/A','mgk')?></td>
			</tr>
		</table>
		
		<p>&nbsp;</p>
		
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table widefat">
			<thead>
				<tr>				
					<!--<th scope="col"><b>#<?php _e('ID','mgk')?></b></th>		-->					
					<th scope="col"><b><?php _e('URL','mgk');?></b></th>										
					<th scope="col"><b><?php _e('Access Date/Time','mgk');?></b></th>											
				</tr>
			</thead>
			<tbody>
				<?php $alt=''; if(count($accessed_urls)==0):?>
				<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>" id="row-0">		
					<td colspan="2" align="center"><?php _e('There are currently no logged urls.','mgk')?></td>
				</tr>
				<?php endif;		
				// show
				foreach ($accessed_urls as $au) :?>
				<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>" id="row-<?php echo $au->id?>">		
					<!--<td valign="top"><?php echo $au->id?></td>	-->								
					<td valign="top"><?php echo $au->url?></td>
					<td valign="top"><?php echo (strtotime($au->access_dt) > 1) ? date($date_long_format, strtotime($au->access_dt)) : __('N/A', 'mgk')?></td>												
				</tr>
				<?php endforeach;?>	
											
			</tbody>				
		</table>
		<br />
		<div align="right">
			<a href="javascript:mgk_url_view_cancel()" class="button"><?php _e('Cancel','mgk')?></a>
		</div>		
		<div class="clearfix"></div>						
	</form>											
	<br />	
	<?php mgk_box_bottom()?>
	<script language="javascript">
		<!--
		// onready
		jQuery(document).ready(function(){   
			// cacel
			mgk_url_view_cancel=function(){
				// remove					
				mgk_remove_tab('#admin_accesslogs .content-div', 1);
				// select
				mgk_select_tab('#admin_accesslogs .content-div', 0);		
			}						
		});	
		//-->		
	</script>
	<?php
}
// end of file