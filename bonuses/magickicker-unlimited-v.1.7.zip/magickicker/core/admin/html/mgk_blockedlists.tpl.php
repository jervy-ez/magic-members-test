<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
/**
 * Admin Module
 *
 * @package WordPress
 * @subpackage magickicker
 * @since 1.0	
 */
 
// get flag
$action_flag=(isset($_REQUEST['mode'])) ? $_REQUEST['mode']: 'index';
// call process
mgk_call_process($action_flag);

/**
 * default tabs
 *
 * @param void
 * @return void
 */
function f_tabs(){
	?>
	<div id="wrap-admin-blockedlists" class="content-div">
		<ul class="tabs">			
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=members"><span class="pngfix"><?php _e('Members','mgk')?></span></a></li>
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=ips"><span class="pngfix"><?php _e('IPs','mgk')?></span></a></li>																												
		</ul>										
	</div>
	<?php
}

/**
 * default list
 *
 * @param void
 * @return void
 */
function f_index(){	
	f_members();		
}

/**
 * default: list of blocked members
 *
 * @param void
 * @return void
 */
function f_members(){
	global $wpdb;
	// pager
	$pager = new mgk_pager();
	// sql		  
	$sql = 'SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email, um.meta_value
			FROM ' . $wpdb->users . ' u	JOIN ' . $wpdb->usermeta . ' um ON (u.ID = um.user_id	
			AND um.meta_key = "mgk_locked_out"	) ORDER BY u.user_login '.$pager->get_query_limit(mgk_get_setting('pagination'));	 
	// echo $sql;		
	// rows	
	$blocked_users=$wpdb->get_results($sql);
	// get page links
	$page_links=$pager->get_pager_links('admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists');
	// date format
	$date_fmt = mgk_get_setting('long_date_format');?>
	<?php mgk_box_top('Blocked Members')?>
	<div align="right"><a href="javascript:mgk_reload_blocked_userlist()"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/arrow_refresh.png" /></a></div> 	
	<div align="right"><?php if($page_links):?><div class="pager-wrap"><?php echo $page_links?></div><?php endif; ?></div>			
		<form name="frmblklist" id="frmblklist" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists">																
			<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table widefat">
				<thead>
					<tr>				
						<th scope="col"><b>#<?php _e('ID','mgk')?></b></th>							
						<th scope="col"><b><?php _e('Username','mgk');?></b></th>
						<th scope="col"><b><?php _e('Email','mgk');?></b></th>												
						<th scope="col"><b><?php _e('Blocked Since','mgk');?></b></th>											
						<th scope="col"><b><?php _e('Action','mgk');?></b></th>
					</tr>
				</thead>
				<tbody id="list-blocked-members">
					<?php $alt=''; if(count($blocked_users)==0):?>
					<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>">		
						<td colspan="5" align="center"><?php _e('There are currently no locked out users.','mgk')?></td>
					</tr>
					<?php endif;						
					// show
					foreach ($blocked_users as $user) :?>
					<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>" id="row-<?php echo $user->ID?>">		
						<td valign="top"><?php echo $user->ID?></td>									
						<td valign="top"><?php echo $user->user_login?></td>
						<td valign="top"><?php echo $user->user_email?></td>	
						<td valign="top"><?php echo ($user->meta_value > 1) ? date($date_fmt, $user->meta_value) : __('Email Activation', 'mgk')?></td>							
						<td valign="top" nowrap="nowrap">
							<a href="javascript:mgk_unlock_user('<?php echo $user->ID ?>')" title="<?php _e('Unlock Member', 'mgk')?>"><img src="<?php echo MGK_ASSETS_URL?>images/icons/lock_open.png" /></a>				
						</td>
					</tr>
					<?php endforeach;?>					
				</tbody>	
			</table>
		</form>		
		<div align="right"><?php if($page_links):?><div class="pager-wrap"><?php echo $page_links?></div><div class="clearfix"></div><?php endif; ?></div>
	<?php mgk_box_bottom()?>
	<script language="javascript">
		<!--
		// set pager
		mgk_set_pager('#admin_blockedlists');
		// reload
		mgk_reload_blocked_userlist=function(){
			jQuery('#admin_blockedlists .content-div').tabs('load',0);
		}		
		// mgk unlock user
		mgk_unlock_user=function(id){
			// confirm
			if(!confirm('<?php _e('You are about to unlock member, are you sure!','mgk')?>')){
				return ;
			}
			// send
			jQuery.ajax({url:'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists',
				type:'POST',
				dataType:'json',
				data:{mode:'unlock_user',id:id},
				beforeSubmit: function(){	
					// show 
					mgk_show_message('#wrap-admin-blockedlists', {status: 'running', message: '<?php _e('Sending request...','mgk')?>'});								  	
			    },
				success: function(data){		
					// show 
					mgk_show_message('#wrap-admin-blockedlists', data, true);	

					// success
					if(data.status=='success'){
						jQuery("#frmblklist #row-"+id).remove();
					}		

					// message 
					var _size = jQuery("#list-blocked-members tr[id^='row-']").size();
					// none
					if( _size == 0 ){
						_html = '<tr class="alternate">'+
								'	<td colspan="5" align="center"><?php _e('There are currently no locked out users.','mgk')?></td>'+
								'</tr>';
						jQuery("#list-blocked-members").append(_html);						
					}
	  			}});
		}	
		//-->
	</script>
	<?php								
}

/**
 * unlock_user
 *
 * @param void
 * @return string
 */
function f_unlock_user(){
	global $wpdb;
	
	// user id
	$user_id = (int)$_POST['id'];
	
	// delete
	delete_user_meta($user_id, 'mgk_locked_out');
	// delete key
	delete_user_meta($user_id, 'mgk_activation_key');

	// success
	echo json_encode(array('status'=>'success','message'=>__('Successfully unlocked selected member from blocked list.','mgk')));exit;
	
}

/**
 * list of blocked IPs
 *
 * @param void
 * @return string
 */
function f_ips(){
	global $wpdb;
	// pager
	$pager = new mgk_pager();
	// sql		  
	$sql = 'SELECT SQL_CALC_FOUND_ROWS `id`,`ip_address`,`blocked_dt` FROM `' . MGK_TBL_BLOCKED_IPS . '` 
	        ORDER BY `ip_address` ASC ' . $pager->get_query_limit(mgk_get_setting('pagination'));	 
	// echo $sql;		 		
	// rows	
	$blocked_ips=$wpdb->get_results($sql);
	// get page links
	$page_links=$pager->get_pager_links('admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=ips');	
	// date format
	$date_fmt = mgk_get_setting('long_date_format');?>
	<?php mgk_box_top('Blocked IPs')?>
	<div align="right">
		<input type="button" class="button" name="ipblock_add" value="<?php _e('Add IP','mgk') . ' &raquo;'?>" onclick="mgk_blip_addnew()"/>
		<a href="javascript:mgk_reload_blocked_iplist()"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/arrow_refresh.png" /></a>
	</div> 	
	<div align="right"><?php if($page_links):?><div class="pager-wrap"><?php echo $page_links?></div><?php endif; ?></div>			
		<form name="frmblkiplist" id="frmblkiplist" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=ips">																
			<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table widefat">
				<thead>
					<tr>				
						<th scope="col"><b>#<?php _e('ID','mgk')?></b></th>
						<th scope="col"><b><?php _e('IP Address','mgk')?></b></th>	
						<th scope="col"><b><?php _e('Blocked Since','mgk')?></b></th>																												
						<th scope="col"><b><?php _e('Action','mgk')?></b></th>
					</tr>
				</thead>
				<tbody>
					<?php $alt=''; if(count($blocked_ips)==0):?>
					<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>" id="row-0">		
						<td colspan="4" align="center"><?php _e('There are currently no blocked IPs.','mgk')?></td>
					</tr>
					<?php endif;	
					
					// show
					foreach ($blocked_ips as $blip) :?>
					<tr class="<?php echo ($alt = ($alt=='') ? 'alternate': '');?>" id="row-<?php echo $blip->id?>">		
						<td valign="top"><?php echo $blip->id?></td>									
						<td valign="top"><?php echo $blip->ip_address?></td>
						<td valign="top"><?php echo date($date_fmt, strtotime($blip->blocked_dt))?></td>
						<td valign="top" nowrap="nowrap">
							<a href="javascript:mgk_blip_edit('<?php echo $blip->id?>')"><img src="<?php echo MGK_ASSETS_URL?>images/icons/edit.png" /></a>
							<a href="javascript:mgk_blip_delete('<?php echo $blip->id?>')"><img src="<?php echo MGK_ASSETS_URL?>images/icons/cross.png" /></a>				
						</td>
					</tr>
					<?php endforeach;?>					
				</tbody>	
			</table>
		</form>		
		<div align="right"><?php if($page_links):?><div class="pager-wrap"><?php echo $page_links?></div><div class="clearfix"></div><?php endif; ?></div>
	<?php mgk_box_bottom()?>
	<script language="javascript">
		<!--
		// onready
		jQuery(document).ready(function(){ 
			// set pager
			mgk_set_pager('#admin_blockedlists',1);
			// reload
			mgk_reload_blocked_iplist=function(){
				jQuery('#admin_blockedlists .content-div').tabs('load',1);
			}	
			// add
			mgk_blip_addnew=function(){		
				// create tab				
				jQuery('#admin_blockedlists .content-div').mgkAutoTabs({index: 2, select: 2, label: '<?php _e('Add IP','mgk')?>', url: 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=add_ip_blocked'});						
			}
			// edit
			mgk_blip_edit=function(id){			
				// create tab
				jQuery('#admin_blockedlists .content-div').mgkAutoTabs({index: 2, select: 2, label: '<?php _e('Edit IP','mgk')?>', url: 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=edit_ip_blocked&id='+id});						
			}
			// delete
			mgk_blip_delete=function(id){
				// confirm
				if(!confirm('<?php _e('You are about to delete one row, are you sure!','mgk')?>')){
					return ;
				}
				// send
				jQuery.ajax({
					url:'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists',
					type:'POST',
					dataType:'json',
					data:{mode:'delete_ip_blocked',id:id},
					beforeSubmit: function(){	
						// show	
						mgk_show_message('#wrap-admin-blockedlists', {status: 'running', message: '<?php _e('Sending request...','mgk')?>'});								  	
					},
					success: function(data){											   														
						// show
						mgk_show_message('#wrap-admin-blockedlists', data, true);

						// success
						if(data.status=='success'){
							jQuery("#frmblkiplist #row-"+id).remove();
						}								   	
					}
				});    			  
			}		
		});	
		//-->
	</script>
	<?php	
}

/**
 * delete blocked ip
 *
 * @param void 
 * @return string
 */
function f_delete_ip_blocked(){
	global $wpdb;
	$sql = 'DELETE FROM `' . MGK_TBL_BLOCKED_IPS . '` WHERE `id` = "'.(int)$_POST['id'].'"';
	$r = $wpdb->query($sql);
	if($r){
		echo json_encode(array('status'=>'success','message'=>__('Successfully deleted selected IP from blocked list.','mgk')));exit;
	}
	// error
	echo json_encode(array('status'=>'success','message'=>__('Error while deleting IP.','mgk')));
}

/**
 * edit blocked ip
 *
 * @param void
 * @return string
 */ 
function f_edit_ip_blocked(){	
	global $wpdb;
	$id = (int)$_GET['id'];
	// save
	if(isset($_POST['process']) && $_POST['process']=='true'){		
		extract($_POST);
		if(!empty($ip_address)){
			// check name unique
			if(mgk_is_duplicate(MGK_TBL_BLOCKED_IPS,array('ip_address'), "AND id<>'{$id}'")){
				$status  ='error';
				$message =__('IP Address is already in database, please provide a different ip address.','mgk');
			}else{
				// data
				$columns = array('ip_address' => $ip_address);	
				// update		
				$success = $wpdb->update(MGK_TBL_BLOCKED_IPS, $columns, array('id'=>$id));
				if($success){
					$status  ='success';
					$message =__('IP block updated successfully.','mgk');
				}else{
					$status  ='error';
					$message =__('Database error occurred','mgk');
				}
			}	
		}else{
			$status  ='error';
			$message =__('IP Address not provided.','mgk');
		}		
		// the response
		echo json_encode(array('status'=>$status,'message'=>$message));
		exit();
	}
	
	$sql = "SELECT * FROM `" . MGK_TBL_BLOCKED_IPS . "` WHERE `id` = '{$id}'";
	$row = $wpdb->get_row($sql);
	// show form
	?>
	<?php mgk_box_top('Edit IP to BlockList')?>	
	<form name="frmblkipedit" id="frmblkipedit" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=edit_ip_blocked&id=<?php echo $id?>">
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table">		
			<tbody>				
				<tr>
					<td width="25%" valign="top"><span class="required-field"><?php _e('IP Address','mgk')?></span></td>
					<td valign="top">
						<input type="text" name="ip_address" id="ip_address" size="40" value="<?php echo $row->ip_address?>"/>
						<div class="tips"><?php _e('Please enter an IP address to block.', 'mgk')?></div>
					</td>
				</tr>								
				<tr>
					<td valign="top"></td>
					<td valign="top">
						<input type="submit" name="btn_save" value="<?php _e('Save','mgk')?>" class="button"/>
						<a href="javascript:mgk_blip_cancel()" class="button"><?php _e('Cancel','mgk')?></a>
					</td>
				</tr>
			</tbody>	
		</table>	
		<input type="hidden" name="process" value="true" />
	</form>											
	<br />	
	<?php mgk_box_bottom()?>
	<script language="javascript">
		<!--
		// onready
		jQuery(document).ready(function(){   
			// cacel
			mgk_blip_cancel=function(){
				// remove					
				mgk_remove_tab('#admin_blockedlists .content-div', 2);
				// select
				mgk_select_tab('#admin_blockedlists .content-div', 1);		
			}			
			// first field focus 	
			jQuery("#frmblkipedit :input:first").focus();
			// ip check			
			mgk_ip_validate('<?php _e('Please specify the correct ip address','mgk')?>');

			// edit form validation
			jQuery("#frmblkipedit").validate({					
				submitHandler: function(form) {					    					
					jQuery("#frmblkipedit").ajaxSubmit({
					  type: "POST",					 
					  dataType: 'json',											 
					  beforeSubmit: function(){	
						// show	
						mgk_show_message('#wrap-admin-blockedlists', {status: 'running', message: '<?php _e('Saving...','mgk')?>'});									  	
					  },
					  success: function(data){	
					  	// show
						mgk_show_message('#wrap-admin-blockedlists', data, true);
						
						// cancel to list
						if(data.status=='success'){		
							// reset input												
							jQuery("#frmblkipedit :input")
								.not(":input[type='hidden']")
								.not(":input[type='submit']")
								.val('');
							// cancel	
							mgk_blip_cancel(data);	
						}													   	
					}});
					// return     		
					return false;											
				},
				rules: {			
					ip_address: {required: true, ipaddress:true}
				},
				messages: {			
					ip_address: {required:"Please enter ip address",ipaddress:"Please valid IP address"}
				},
				errorClass: 'validation-error'
			});				
		});	
		//-->		
	</script>
	<?php
}

/**
 * add blocked ip address 
 *
 * @param void
 * @return string
 */
function f_add_ip_blocked(){
	global $wpdb;
	// save
	if(isset($_POST['process']) && $_POST['process']=='true'){		
		extract($_POST);
		if(!empty($ip_address)){
			// check name unique
			if(mgk_is_duplicate(MGK_TBL_BLOCKED_IPS,array('ip_address'))){
				$status  ='error';
				$message =__('IP Address is already in database, please provide a different ip address.','mgk');
			}else{
				$columns = array('ip_address' => $ip_address, 'blocked_dt'=>date('Y-m-d H:i:s'));			
				$success = $wpdb->insert(MGK_TBL_BLOCKED_IPS, $columns);
				if($success){
					$status  = 'success';
					$message = __('IP blocked successfully.','mgk');
				}else{
					$status  = 'error';
					$message = __('Database error occurred','mgk');
				}
			}	
		}else{
			$status  = 'error';
			$message = __('IP Address not provided.','mgk');
		}		
		// the response
		echo json_encode(array('status'=>$status,'message'=>$message));
		exit();
	}
	
	// show form
	?>
	<?php mgk_box_top('Add IP to BlockList')?>	
	<form name="frmblkipadd" id="frmblkipadd" method="post" action="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=add_ip_blocked">
		<table width="100%" cellpadding="1" cellspacing="0" border="0" class="form-table">		
			<tbody>				
				<tr>
					<td width="25%" valign="top"><span class="required-field"><?php _e('IP Address','mgk')?></span></td>
					<td valign="top">
						<input type="text" name="ip_address" id="ip_address" size="40"/>
						<div class="tips"><?php _e('Please enter an IP address to block.', 'mgk')?></div>
					</td>
				</tr>								
				<tr>
					<td valign="top"></td>
					<td valign="top">
						<input type="submit" name="btn_save" value="<?php _e('Save','mgk')?>" class="button"/>
						<a href="javascript:mgk_blip_cancel()" class="button"><?php _e('Cancel','mgk')?></a>
					</td>
				</tr>
			</tbody>	
		</table>	
		<input type="hidden" name="process" value="true" />
	</form>											
	<br />	
	<?php mgk_box_bottom()?>
	<script language="javascript">
		<!--
		// onready
		jQuery(document).ready(function(){   
			// cacel
			mgk_blip_cancel=function(){
				// remove					
				mgk_remove_tab('#admin_blockedlists .content-div', 2);
				// select
				mgk_select_tab('#admin_blockedlists .content-div', 1);		
			}			

			// first field focus 	
			jQuery("#frmblkipadd :input:first").focus();
			// ip address check
			mgk_ip_validate('<?php _e('Please specify the correct ip address','mgk')?>');
							
			// add login form validation
			jQuery("#frmblkipadd").validate({					
				submitHandler: function(form) {					    					
					jQuery("#frmblkipadd").ajaxSubmit({
					  type: "POST",					  
					  dataType: 'json',											 
					  beforeSubmit: function(){	
						// show	
						mgk_show_message('#wrap-admin-blockedlists', {status: 'running', message: '<?php _e('Saving...','mgk')?>'});								  	
					  },
					  success: function(data){	
					  	// show
						mgk_show_message('#wrap-admin-blockedlists', data, true);
						
						// cancel to list
						if(data.status=='success'){		
							// clean inputs												
							jQuery("#frmblkipadd :input")
								.not(":input[type='hidden']")
								.not(":input[type='submit']")
								.val('');
							// cancel	
							mgk_blip_cancel(data);	
						}													   	
					}});
					// return    		
					return false;											
				},
				rules: {			
					ip_address: {required: true, ipaddress:true}
				},
				messages: {			
					ip_address: {required:"Please enter ip address",ipaddress:"Please valid IP address"}
				},
				errorClass: 'validation-error'
			});				
		});	
		//-->		
	</script>
	<?php
}

// end of file