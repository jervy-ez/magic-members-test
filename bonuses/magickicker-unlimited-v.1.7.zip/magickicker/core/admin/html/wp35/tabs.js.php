<script language="javascript">
	//<![CDATA[
	jQuery(document).ready(function(){		
		// attach loading mask
		mgk_ajax_loader();		

		// create tabs
		mgk_primary_tabs = jQuery( "#mgk-panel-content" ).tabs({
			// before load
			beforeLoad: function( event, ui ) {			
				ui.jqXHR.error(function() {
					ui.panel.html(	"<?php _e('Couldn\'t load this tab. We\'ll try to fix this as soon as possible.','mgk')?>" );
				});
			},

			load: function( event, ui ) {			
				// create secondary tabs										
				mgk_secondary_tabs = jQuery(ui.panel).find('.content-div').tabs({ 				
					beforeActivate: function( event, ui ){
						jQuery('#message').remove();
					},
					load: function( event, ui ){
						mgk_attach_tips();
					} 											  
				}); 
			}
		});

		// add last css
		jQuery('#mgk-panel-mainmenu li:last').addClass('last');	
	});
	//]]>
</script>