/* old 
// create main inline tabs	
jQuery('#mgk-panel-content').tabs({ fx: { opacity: 'toggle' }, idPrefix: 'ui-tabs-primary' });
// create sub ajax tabs
jQuery('.content-div').tabs({ 
	fx: { opacity: 'toggle' }, cache: false, idPrefix: 'ui-tabs-secondary',
		  spinner: "<?php _e('Loading','mgk')?>",
          load: function(event,ui){mgk_attach_tips();}, 
		  select: function(event,ui){jQuery('#message').remove()}
});
*/