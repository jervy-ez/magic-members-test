<!-- mgk-panel mainmenu -->
<ul id="mgk-panel-mainmenu">	
	<?php if( $mgk_authed ):?>
	<li aria-controls="admin_dashboard"><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=admin&mode=tabs" title="<?php _e('Dashboard','mgk')?>"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/anchor.png" class="pngfix" alt="" /><?php _e('Dashboard','mgk')?></a></li>
	<li aria-controls="admin_blockedlists"><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=tabs" title="<?php _e('Blocked Lists','mgk')?>"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/lock.png" class="pngfix" alt="" /><?php _e('Blocked Lists','mgk')?></a></li>
	<li aria-controls="admin_accesslogs"><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=tabs" title="<?php _e('Access Logs','mgk')?>"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/database_key.png" class="pngfix" alt="" /><?php _e('Access Logs','mgk')?></a></li>
	<li aria-controls="admin_settings"><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=tabs" title="<?php _e('Settings','mgk')?>"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/page_white_gear.png" class="pngfix" alt="" /><?php _e('Settings','mgk')?></a></li>
	<?php else:?>
	<li aria-controls="admin_activation"><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=admin&mode=tabs" title="<?php _e('Magic Kicker','mgk')?>"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/anchor.png" class="pngfix" alt="" /><?php _e('Magic Kicker','mgk')?></a></li>
	<?php endif;?>
</ul>
<!-- end mgk-panel mainmenu -->

<?php @include('tabs.js.php');?>