<script language="javascript">
	//<![CDATA[
	jQuery(document).ready(function(){			
		// attach loading mask
		mgk_ajax_loader();		

		// create main inline tabs	
		mgk_primary_tab_urls = [];
		// create tabs
		mgk_primary_tabs = jQuery('#mgk-panel-content').tabs({ 
			fx: { opacity: 'toggle' }, idPrefix: 'ui-tabs-primary', 
		  	load : function(event,ui){
		  		/*
		  	  	// set next urls								  	
			  	jQuery('#mgk-panel-mainmenu li a[href][title]').each(function(index){
					// home page already loaded								
					if( index > 0 ){													
						// get url
						url = jQuery(this).attr('href').replace('#','').replace('_','/');		
						// add
						if(jQuery.inArray(url, mgk_primary_tab_urls) == -1){	
							// set url																				
							mgk_primary_tabs.tabs('url', index, 'admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/' + url);	
							// store url					
							mgk_primary_tab_urls.push(url);
						}
					}
				});	*/		

			 	// create secondary tabs										
			  	mgk_secondary_tabs = jQuery('.content-div').tabs({ 
					fx: { opacity: 'toggle' }, cache: false, idPrefix: 'ui-tabs-secondary',
					spinner: '<?php _e('Loading...','mgk')?>',
					// load: function(event,ui){ mgk_attach_tips(); }, 
					select: function(event,ui){
						jQuery('#message').remove();
					}											  
			  	}); // end secondary tabs										
		    }
		}); // end primary tabs	
		  
		// add last css
		jQuery('#mgk-panel-mainmenu li:last').addClass('last');		
	});
	//]]>
</script>