<div id="admin_home">
	<div id="wrap-admin-home" class="content-div">
		<ul class="tabs">			
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=dashboard"><span class="pngfix"><?php echo _e('Dashboard','mgk')?></span></a></li>				
		</ul>										
	</div>
</div>
<?php if( $mgk_authed ):?>
	
<div id="admin_blockedlists">
	<div id="wrap-admin-blockedlists" class="content-div">
		<ul class="tabs">			
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=members"><span class="pngfix"><?php _e('Members','mgk')?></span></a></li>
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=ips"><span class="pngfix"><?php _e('IPs','mgk')?></span></a></li>																												
		</ul>										
	</div>
</div>	
<div id="admin_accesslogs">
	<div id="wrap-admin-accesslogs" class="content-div">
		<ul class="tabs">			
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=members"><span class="pngfix"><?php _e('Members','mgk')?></span></a></li>										
		</ul>										
	</div>
</div>							
<div id="admin_settings">
	<div id="wrap-admin-settings" class="content-div">
		<ul class="tabs">			
			<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=general"><span class="pngfix"><?php _e('General','mgk')?></span></a></li>																				
			<!--<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=emailtemplates"><span class="pngfix"><?php _e('Email Templates','mgk')?></span></a></li>-->
		</ul>										
	</div>								
</div>		
<?php endif;?>	

/* old
		// create main inline tabs	
		jQuery('#mgk-panel-content').tabs({ fx: { opacity: 'toggle' }, idPrefix: 'ui-tabs-primary' });
		// create sub ajax tabs
		jQuery('.content-div').tabs({ 
			fx: { opacity: 'toggle' }, cache: false, idPrefix: 'ui-tabs-secondary',
				  spinner: "<?php _e('Loading','mgk')?>",
                  load: function(event,ui){mgk_attach_tips();}, 
				  select: function(event,ui){jQuery('#message').remove()}
		});*/