<ul id="mgk-panel-mainmenu">	
	<?php if( $mgk_authed ):?>
	<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=admin&mode=tabs" title="admin dashboard"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/anchor.png" class="pngfix" alt="" /><?php _e('Dashboard','mgk')?></a></li>
	<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=blockedlists&mode=tabs" title="admin blockedlists"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/lock.png" class="pngfix" alt="" /><?php _e('Blocked Lists','mgk')?></a></li>
	<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=accesslogs&mode=tabs" title="admin accesslogs"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/database_key.png" class="pngfix" alt="" /><?php _e('Access Logs','mgk')?></a></li>
	<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=settings&mode=tabs" title="admin settings"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/page_white_gear.png" class="pngfix" alt="" /><?php _e('Settings','mgk')?></a></li>
	<?php else:?>
	<li><a href="admin-ajax.php?action=mgk_admin_ajax_action&page=mgk/admin&load=admin&mode=tabs" title="admin activation"><img src="<?php echo MGK_ASSETS_URL ?>images/icons/anchor.png" class="pngfix" alt="" /><?php _e('Magic Kicker','mgk')?></a></li>
	<?php endif;?>
</ul><!-- end mgk-panel mainmenu -->

<!--tabs contents-->		
<div id="admin_dashboard"></div>
<div id="admin_blockedlists"></div>
<div id="admin_accesslogs"></div>
<div id="admin_settings"></div>
<div id="admin_activation"></div>							
<!--/tab contents-->

<?php @include('tabs.js.php');?>