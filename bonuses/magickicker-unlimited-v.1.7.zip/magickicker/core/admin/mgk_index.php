<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed'); ?>
<div class="wrap">
	<div id="mgk-wrapper">
		<div id="mgk-panel-wrap">
			<div id="mgk-panel-wrapper">
				<div id="mgk-panel">
					<div id="mgk-panel-content-wrap">
						<?php $mgk_authed = mgk_get_auth();?>
						<div id="mgk-panel-content">
							<!--logo-->
							<a href="admin.php?page=mgk/admin"><img src="<?php echo MGK_ASSETS_URL ?>images/kicker-logo.jpg" alt="mgk-panel" class="pngfix" id="mgk-panel-logo" width="150" height="70"/></a>
							<!--end logo-->

							<?php 
							// 3.5+
							if ( mgk_compare_wp_version( '3.5', '>=' ) ):
								$dir = 'wp35';
							else:// older
								$dir = 'wp34';
							endif;
							
							// include
							@include( sprintf( 'html/%s/tabs.layout.php', $dir) );?>

						</div> <!-- end mgk-panel-content div -->
					</div> <!-- end mgk-panel-content-wrap div -->
				</div> <!-- end mgk-panel div -->
			</div> <!-- end mgk-panel-wrapper div -->
			<div id="mgk-panel-bottom">   	
				<?php mgk_render_infobar()?>	
			</div><!-- end mgk-panel-bottom div -->
			<div style="clear: both;"></div>
		</div> <!-- end panel-wrap div -->
	</div> <!-- end wrapper div -->
</div>
