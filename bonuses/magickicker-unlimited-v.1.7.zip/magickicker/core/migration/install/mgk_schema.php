<?php
// table schema
$charset_collate = mgk_get_charset_collate();
// block list
$sql = "CREATE TABLE IF NOT EXISTS `".MGK_TBL_BLOCKED_IPS."` (
		`id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		`ip_address` VARCHAR( 20 ) NOT NULL,
		`blocked_dt` DATETIME NOT NULL,
		 PRIMARY KEY (  `id` )
		) {$charset_collate} COMMENT='Blocked ip records';";
$wpdb->query($sql);	
// ip logs
$sql = "CREATE TABLE IF NOT EXISTS `".MGK_TBL_USER_IPS."` (
		  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		  `user_id` bigint(20) unsigned NOT NULL,
		  `ip_address` varchar(20) NOT NULL,
		  `access_dt` DATETIME NOT NULL,
		  `logout_at` DATETIME NULL, 
		   PRIMARY KEY  (`id`)
		) {$charset_collate} COMMENT='IP log records';";
$wpdb->query($sql);	
// page logs
$sql = "CREATE TABLE IF NOT EXISTS `".MGK_TBL_ACCESSED_URLS."` (
		  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		  `ip_id` bigint(20) unsigned NOT NULL,
		  `url` TEXT NOT NULL, 
		  `access_dt` DATETIME NOT NULL,		  
		   PRIMARY KEY  (`id`)
		) {$charset_collate} COMMENT='URL log records';";
$wpdb->query($sql);		
// end of file