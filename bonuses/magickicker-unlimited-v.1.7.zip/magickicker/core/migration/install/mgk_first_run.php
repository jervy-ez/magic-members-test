<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
// first run

// create schema
require_once('mgk_schema.php');

// create options
require_once('mgk_options.php');

// end of file