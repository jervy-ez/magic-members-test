<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
	// table schema	
	
	// id bigint
 	$sql = "ALTER TABLE `".MGK_TBL_BLOCKED_IPS."` CHANGE `id` `id` BIGINT( 20 ) UNSIGNED NOT NULL AUTO_INCREMENT;";
 	$wpdb->query($sql);
	
	// id bigint
 	$sql = "ALTER TABLE `".MGK_TBL_USER_IPS."` CHANGE `id` `id` BIGINT( 20 ) UNSIGNED NOT NULL AUTO_INCREMENT;";
 	$wpdb->query($sql);
	
	// id bigint
 	$sql = "ALTER TABLE `".MGK_TBL_ACCESSED_URLS."` CHANGE `id` `id` BIGINT( 20 ) UNSIGNED NOT NULL AUTO_INCREMENT,
			CHANGE `ip_id` `ip_id` BIGINT( 20 ) UNSIGNED NOT NULL";
 	$wpdb->query($sql);
	
// end file