<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
	// table schema	
	
	$sql = "ALTER TABLE `".MGK_TBL_USER_IPS."` ADD `logout_at` DATETIME NULL;";
 	$wpdb->query($sql);	
	
// end file