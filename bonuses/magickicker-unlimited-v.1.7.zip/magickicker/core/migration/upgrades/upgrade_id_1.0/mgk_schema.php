<?php
// table schema	
// ALTER TABLE `wp_mgk_block_list` CHANGE `ip` `ip_address` VARCHAR( 20 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL 
?>	