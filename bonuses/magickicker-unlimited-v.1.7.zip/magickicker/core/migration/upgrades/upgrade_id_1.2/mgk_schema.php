<?php if ( !defined('ABSPATH') ) exit('No direct script access allowed');
	// table schema	
	// charset and collate
 	$charset_collate = mgk_get_charset_collate(); 
	
	// alter charsets
	foreach(mgk_get_tables() as $table){
		$sql = "ALTER TABLE `{$table}` {$charset_collate}"; 
		$wpdb->query($sql);
	}	
	
	// reset collat
	mgk_reset_tables_collate();
?>	